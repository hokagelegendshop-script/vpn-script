#!/bin/bash
clear
read -p "Username Baru : " user

if grep -qw "^\"$user\"" /etc/ppp/chap-secrets || grep -qw "^$user" /etc/ppp/chap-secrets; then
    echo "❌ Username sudah ada! Silakan gunakan nama lain."
    exit 0
fi

read -p "Password      : " pass
read -p "Expired (Hari): " masaaktif

exp=$(date -d "+${masaaktif} days" +"%Y-%m-%d")
MYIP=$(curl -s ifconfig.me)

# Melacak PSK asli langsung dari jantung database IPSec
SECRET_PSK=$(awk -F'"' '/PSK/ {print $2}' /etc/ipsec.secrets)

# Menyuntikkan data tanpa perlu me-restart layanan
echo "\"$user\" * \"$pass\" * # Exp: $exp" >> /etc/ppp/chap-secrets

clear
echo "====================================================="
echo "                 AKUN BERHASIL DIBUAT                "
echo "====================================================="
echo "Protokol   : SSTP, L2TP/IPSec, PPTP"
echo "IP Server  : $MYIP"
echo "Username   : $user"
echo "Password   : $pass"
echo "IPSec PSK  : $SECRET_PSK"
echo "Expired    : $exp"
echo "====================================================="
