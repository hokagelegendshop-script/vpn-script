#!/bin/bash
clear

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'
purple="\033[1;95m"

FILE_SECRETS="/etc/ppp/chap-secrets"
DIR_CONFIG="/usr/bin/vpn-script/dashboard-user/config-l2tp"
mkdir -p "$DIR_CONFIG"

echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
echo -e "${purple}               BUAT AKUN L2TP BARU                  ${NC}"
echo -e "${CYAN}════════════════════════════════════════════════════${NC}"

read -p "Masukkan Username : " user

# Validasi agar username tidak boleh kosong
if [[ -z "$user" ]]; then
    echo -e "${RED}Gagal: Username tidak boleh kosong!${NC}"
    sleep 2
    exit 1
fi

# Cek apakah username sudah ada (khusus jalur xl2tpd atau *)
cek=$(awk -v u="$user" '($1 == u || $1 == "\""u"\"") && ($2 == "xl2tpd" || $2 == "*")' "$FILE_SECRETS" | wc -l)
if [ "$cek" -gt 0 ]; then
    echo -e "${RED}Gagal: Username '$user' sudah terdaftar!${NC}"
    echo ""
    read -n 1 -s -r -p "Tekan [Enter] untuk kembali..."
    exit 1
fi

read -p "Masukkan Password : " pass
read -p "Masa Aktif (Hari) : " masaaktif
read -p "Limit IP (0=Bebas): " limit_ip
read -p "Limit Kuota MB (0=Bebas) : " limit_kuota

# --- SET DEFAULT VALUE JIKA KOSONG (TEKAN ENTER) ---
masaaktif=${masaaktif:-30}
limit_ip=${limit_ip:-0}
limit_kuota=${limit_kuota:-0}
# ---------------------------------------------------

exp=$(date -d "+${masaaktif} days" +"%Y-%m-%d")
ipsaya=$(curl -sSL ifconfig.me | tr -d '\n' | tr -d '\r' | tr -d ' ')

# Mengambil IPsec PSK dari konfigurasi StrongSwan
psk=$(grep -i "PSK" /etc/ipsec.secrets | cut -d'"' -f2 | head -n 1)

# Simpan ke chap-secrets dengan label xl2tpd
echo "\"$user\" xl2tpd \"$pass\" * # Exp: $exp" >> "$FILE_SECRETS"

# Simpan konfigurasi limit & kuota ke file user untuk dibaca limit-checker
cat <<EOF > "${DIR_CONFIG}/${user}.conf"
Username=$user
Expired=$exp
LimitIP=$limit_ip
LimitKuota=$limit_kuota
EOF

clear
echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}            AKUN L2TP BERHASIL DIBUAT               ${NC}"
echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
echo -e "Username    : ${user}"
echo -e "Password    : ${pass}"
echo -e "IPsec PSK   : ${psk}"
echo -e "IP Address  : ${ipsaya}"
echo -e "Expired     : ${exp}"
echo -e "Limit IP    : ${limit_ip} Device"
echo -e "Limit Kuota : ${limit_kuota} Megabytes"
echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
echo ""
read -n 1 -s -r -p "Ketik Enter untuk kembali..."