#!/bin/bash
clear
# ==========================================
# Definisi Warna untuk Indikator
# ==========================================
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color
purple="\033[1;95m"
y='\033[1;33m' #yellow

print_yellow() {
    echo -e "${y}$1${NC}"
}

print_yellow "════════════════════════════════════════════════════"
echo -e "${purple}            HAPUS AKUN WIREGUARD                          ${NC} "
print_yellow "       ══════════════════════════════════      "
print_yellow "══════════════════════════════════════════════════════════════════════"
printf "%-5s | %-15s | %-14s | %-12s | %-15s\n" "NO" "USERNAME" "IP ADDRESS" "TGL EXPIRED" "SISA AKTIF"
print_yellow "══════════════════════════════════════════════════════════════════════"

# Ambil waktu hari ini dalam detik (Epoch)
today_sec=$(date +%s)

# Deklarasi Array untuk menyimpan daftar username berdasarkan nomor
declare -a user_array
count=1

# Membaca daftar client dari file konfigurasi menggunakan proses substitusi
while read -r line; do
    # Ekstrak username dan tanggal expired
    user_list=$(echo "$line" | awk '{print $3}')
    exp_list=$(echo "$line" | awk '{print $4}')
    
    # Simpan username ke dalam array berdasarkan nomor urut (count)
    user_array[$count]="$user_list"
    
    # Ekstrak IP Address
    ip_address=$(grep -A 4 "^### Client $user_list\b" /etc/wireguard/wg0.conf | grep "AllowedIPs" | awk '{print $3}' | cut -d '/' -f 1)
    
    # Konversi tanggal expired ke detik untuk dihitung
    exp_sec=$(date -d "$exp_list" +%s 2>/dev/null)
    
    # Hitung selisih detik, lalu ubah ke format hari (1 hari = 86400 detik)
    diff_sec=$((exp_sec - today_sec))
    diff_days=$((diff_sec / 86400))
    
    # Penentuan status masa aktif
    if [ "$diff_days" -lt 0 ]; then
        status="\033[0;31mExpired ($diff_days)\033[0m"
    elif [ "$diff_days" -eq 0 ]; then
        status="\033[1;33mHari ini\033[0m"
    else
        status="\033[0;32m$diff_days Hari\033[0m"
    fi
    
    # Cetak ke layar dengan format tabel yang sejajar
    printf "%-5s | %-15s | %-14s | %-12s | %-25b\n" "[$count]" "$user_list" "$ip_address" "$exp_list" "$status"
    
    # Tambah nomor urut untuk baris selanjutnya
    ((count++))
done < <(grep "^### Client" /etc/wireguard/wg0.conf)

print_yellow "══════════════════════════════════════════════════════════════════════"

# Meminta input: Bisa Nomor atau Username, 0 untuk Batal
read -p "Masukkan Nomor/Username yang akan dihapus (0 untuk Batal): " input_user

# LOGIKA PEMBATALAN (CANCEL)
if [[ -z "$input_user" || "$input_user" == "0" ]]; then
    echo -e "\n\033[1;33mProses dibatalkan. Kembali ke menu sebelumnya...\033[0m"
    sleep 1
    bash /usr/bin/vpn-script/script/menu-wg.sh
    exit 0
fi

# LOGIKA PEMILIHAN (NOMOR ATAU USERNAME)
target_user="$input_user"
# Cek apakah input berupa angka murni
if [[ "$input_user" =~ ^[0-9]+$ ]]; then
    # Cek apakah angka yang dimasukkan ada di dalam daftar nomor urut
    if (( input_user > 0 && input_user < count )); then
        # Ubah target_user menjadi username yang sesuai dengan nomor urut tersebut
        target_user="${user_array[$input_user]}"
    fi
fi

# Validasi apakah user target ada di database
if grep -qw "^### Client $target_user\b" /etc/wireguard/wg0.conf; then
    # Dapatkan Public Key secara presisi menggunakan batas \b (boundary)
    PUB_KEY=$(grep -A 3 "^### Client $target_user\b" /etc/wireguard/wg0.conf | grep "PublicKey" | awk '{print $3}')
    
    # Hapus dari service wg0 secara instan tanpa perlu restart
    wg set wg0 peer "$PUB_KEY" remove
    
    # Hapus blok konfigurasi dari wg0.conf
    sed -i "/^### Client $target_user\b/,/^AllowedIPs/d" /etc/wireguard/wg0.conf
    
    # Hapus file konfigurasinya
    rm -f "/usr/bin/vpn-script/dashboard-user/config-wg/$target_user.conf"
    
    echo -e "\033[0;32mAkun '$target_user' berhasil dihapus secara permanen!\033[0m"
else
    echo -e "\033[0;31mAkun '$target_user' tidak ditemukan di database!\033[0m"
fi

echo "====================================================================="
echo "Ketik Enter untuk kembali..."
read
bash /usr/bin/vpn-script/script/menu-wg.sh