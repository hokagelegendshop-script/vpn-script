#!/bin/bash
clear
echo "=========================================================="
echo "                 PERPANJANG AKUN WIREGUARD                "
echo "=========================================================="
echo " DAFTAR AKUN SAAT INI:"
echo "----------------------------------------------------------"
printf "%-5s | %-15s | %-12s | %-15s\n" "NO" "USERNAME" "TGL EXPIRED" "SISA AKTIF"
echo "----------------------------------------------------------"

# Ambil waktu hari ini dalam detik (Epoch)
today_sec=$(date +%s)

# Deklarasi Array untuk menyimpan daftar username berdasarkan nomor
declare -a user_array
count=1

# Membaca daftar client dari file konfigurasi menggunakan proses substitusi
while read -r line; do
    # Ekstrak username dan tanggal expired
    user_list=$(echo "$line" | awk '{print $3}')
    exp_list=$(echo "$line" | awk '{print $4}')
    
    # Simpan username ke dalam array berdasarkan nomor urut (count)
    user_array[$count]="$user_list"
    
    # Konversi tanggal expired ke detik untuk dihitung
    exp_sec=$(date -d "$exp_list" +%s 2>/dev/null)
    
    # Hitung selisih detik, lalu ubah ke format hari (1 hari = 86400 detik)
    diff_sec=$((exp_sec - today_sec))
    diff_days=$((diff_sec / 86400))
    
    # Penentuan status masa aktif
    if [ "$diff_days" -lt 0 ]; then
        status="\033[0;31mExpired ($diff_days)\033[0m"
    elif [ "$diff_days" -eq 0 ]; then
        status="\033[1;33mHari ini\033[0m"
    else
        status="\033[0;32m$diff_days Hari\033[0m"
    fi
    
    # Cetak ke layar dengan tambahan kolom Nomor (NO)
    printf "%-5s | %-15s | %-12s | %-25b\n" "[$count]" "$user_list" "$exp_list" "$status"
    
    # Tambah nomor urut untuk baris selanjutnya
    ((count++))
done < <(grep "^### Client" /etc/wireguard/wg0.conf)

echo "----------------------------------------------------------"
echo ""

# Meminta input: Bisa Nomor atau Username, 0 untuk Batal
read -p "Masukkan Nomor atau Username (0 untuk Batal): " input_user

# LOGIKA PEMBATALAN (CANCEL)
if [[ -z "$input_user" || "$input_user" == "0" ]]; then
    echo -e "\n\033[1;33mProses dibatalkan. Kembali ke menu sebelumnya...\033[0m"
    sleep 1
    bash /usr/bin/vpn-script/script/menu-wg.sh
    exit 0
fi

# LOGIKA PEMILIHAN (NOMOR ATAU USERNAME)
target_user="$input_user"
# Cek apakah input berupa angka murni
if [[ "$input_user" =~ ^[0-9]+$ ]]; then
    # Cek apakah angka yang dimasukkan ada di dalam daftar nomor urut
    if (( input_user > 0 && input_user < count )); then
        # Ubah target_user menjadi username yang sesuai dengan nomor urut tersebut
        target_user="${user_array[$input_user]}"
    fi
fi

# Validasi apakah user target ada di database
if grep -qw "^### Client $target_user" /etc/wireguard/wg0.conf; then
    echo -e "User terpilih: \033[0;36m$target_user\033[0m"
    read -p "Tambah masa aktif (Hari): " exp
    
    # Ambil tanggal expired lama
    old_exp=$(grep "^### Client $target_user" /etc/wireguard/wg0.conf | awk '{print $4}')
    
    # Cek expired date dengan logika
    today=$(date +%Y-%m-%d)
    if [[ "$today" > "$old_exp" ]]; then
        # Jika sudah expired, hitung perpanjangan dari hari ini
        new_exp=$(date -d "+$exp days" +"%Y-%m-%d")
    else
        # Jika masih aktif, akumulasikan/tambahkan dari sisa hari yang ada
        new_exp=$(date -d "$old_exp + $exp days" +"%Y-%m-%d")
    fi
    
    # Update tanggal di wg0.conf
    sed -i "s/^### Client $target_user $old_exp/### Client $target_user $new_exp/" /etc/wireguard/wg0.conf
    
    echo -e "\033[0;32mMasa aktif akun '$target_user' berhasil diperpanjang hingga $new_exp\033[0m"
else
    echo -e "\033[0;31mAkun '$target_user' tidak ditemukan di database!\033[0m"
fi
echo "=========================================================="
echo "Ketik Enter untuk kembali..."
read
bash /usr/bin/vpn-script/script/menu-wg.sh