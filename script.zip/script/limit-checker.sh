#!/bin/bash

# Ambil pengaturan Global Limit dari Bot Telegram
settings_file="/usr/bin/vpn-script/bot-telegram/core/settings.json"
global_limit_ip=$(grep -oP '"limit_ip": \K\d+' "$settings_file" 2>/dev/null || echo 3)
global_limit_quota=$(grep -oP '"limit_quota_mb": \K\d+' "$settings_file" 2>/dev/null || echo 204800)

# A. Pemantauan Limit Kuota WireGuard (dalam Megabytes)
wg_conf="/etc/wireguard/wg0.conf"
grep "^### Client" "$wg_conf" | while read -r line; do
    user=$(echo "$line" | awk '{print $3}')
    limit_quota=$(echo "$line" | awk '{print $6}')
    pubkey=$(grep -A 2 "^### Client $user\b" "$wg_conf" | grep "PublicKey" | awk '{print $3}')
    
    # Gunakan global limit jika kuota bernilai 0 di file config
    if [ -z "$limit_quota" ] || [ "$limit_quota" -eq 0 ]; then
        limit_quota=$global_limit_quota
    fi
    
    traffic=$(wg show wg0 transfer | grep "$pubkey")
    if [ -n "$traffic" ]; then
        rx_bytes=$(echo "$traffic" | awk '{print $2}')
        tx_bytes=$(echo "$traffic" | awk '{print $3}')
        total_mb=$(((rx_bytes + tx_bytes) / 1024 / 1024))
        
        if [ "$total_mb" -ge "$limit_quota" ]; then
            wg set wg0 peer "$pubkey" remove
            sed -i "s/^### Client $user/### QuotaExceeded $user/" "$wg_conf"
        fi
    fi
done

# B. Pemantauan Limit IP/Device (Multi-Login L2TP & PPTP)
for user in $(awk -F'"' '/^"/ {print $2}' /etc/ppp/chap-secrets); do
    # Hitung jumlah proses aktif per user
    login_count=$(ps -ef | grep pppd | grep -w "$user" | grep -v grep | wc -l)
    
    if [ "$login_count" -gt "$global_limit_ip" ]; then
        # Jika melebihi limit IP, putuskan paksa semua koneksi user tersebut
        kill $(ps -ef | grep pppd | grep -w "$user" | grep -v grep | awk '{print $2}') 2>/dev/null
    fi
done
