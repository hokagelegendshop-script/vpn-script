#!/bin/bash
clear

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'
purple="\033[1;95m"

FILE_SECRETS="/etc/ppp/chap-secrets"
DIR_CONFIG="/usr/bin/vpn-script/dashboard-user/config-pptp"

echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
echo -e "${purple}                   EDIT AKUN PPTP                   ${NC}"
echo -e "${CYAN}════════════════════════════════════════════════════${NC}"

# Menampilkan daftar user untuk mempermudah
users=($(awk '$2 == "pptpd" {print $1}' "$FILE_SECRETS" | tr -d '"'))
if [ ${#users[@]} -eq 0 ]; then
    echo -e "${RED}Tidak ada akun PPTP yang terdaftar.${NC}"
    echo ""
    read -n 1 -s -r -p "Tekan [Enter] untuk kembali..."
    exit 1
fi

echo -e "Daftar Akun PPTP:"
for i in "${!users[@]}"; do
    echo -e " [${GREEN}$((i+1))${NC}] ${users[$i]}"
done
echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
read -p "Pilih Nomor atau ketik Username yang akan diedit : " input

if [[ "$input" =~ ^[0-9]+$ ]] && [ "$input" -ge 1 ] && [ "$input" -le "${#users[@]}" ]; then
    user="${users[$((input-1))]}"
else
    user="$input"
fi

# Validasi Keberadaan Akun
cek=$(awk -v u="$user" '($1 == u || $1 == "\""u"\"") && $2 == "pptpd"' "$FILE_SECRETS" | wc -l)
if [ "$cek" -eq 0 ]; then
    echo -e "\n${RED}Gagal: Akun PPTP '$user' tidak ditemukan!${NC}"
    sleep 2
    exit 1
fi

# Ambil data lama
old_pass=$(awk -v u="$user" '($1 == u || $1 == "\""u"\"") && $2 == "pptpd" {print $3}' "$FILE_SECRETS" | tr -d '"')
conf_file="${DIR_CONFIG}/${user}.conf"

if [ -f "$conf_file" ]; then
    exp=$(grep "^Expired=" "$conf_file" | cut -d= -f2)
else
    exp=$(grep -w "^\"*$user\"*" "$FILE_SECRETS" | grep "pptpd" | awk -F"Exp: " '{print $2}')
    if [ -z "$exp" ]; then exp=$(date -d "+30 days" +"%Y-%m-%d"); fi
fi

echo -e "\n${YELLOW}Pilih Data yang Ingin Diubah untuk '$user':${NC}"
echo -e " ${GREEN}[1]${NC} Ubah Username"
echo -e " ${GREEN}[2]${NC} Ubah Password"
echo -e " ${GREEN}[3]${NC} Perpanjang Masa Aktif (Renew)"
echo -e " ${RED}[0]${NC} Batal / Kembali"
read -p "Masukkan Pilihan [0-3] : " edit_opt

case $edit_opt in
    1)
        echo -e "\n${CYAN}--- UBAH USERNAME ---${NC}"
        read -p "Masukkan Username Baru : " new_user
        if [[ -z "$new_user" || "$new_user" == "$user" ]]; then
            echo -e "${RED}Username tidak valid atau sama dengan sebelumnya!${NC}"; sleep 2; exit 1
        fi
        
        # Pastikan username baru belum dipakai
        cek_new=$(awk -v u="$new_user" '($1 == u || $1 == "\""u"\"") && ($2 == "pptpd" || $2 == "*")' "$FILE_SECRETS" | wc -l)
        if [ "$cek_new" -gt 0 ]; then
            echo -e "${RED}Gagal: Username '$new_user' sudah terdaftar!${NC}"; sleep 2; exit 1
        fi
        
        # Hapus data lama dan insert data baru di chap-secrets
        sed -i "/^\"*${user}\"*[[:space:]]\+pptpd[[:space:]]/d" "$FILE_SECRETS"
        echo "\"$new_user\" pptpd \"$old_pass\" * # Exp: $exp" >> "$FILE_SECRETS"
        
        # Rename dan update file conf
        if [ -f "$conf_file" ]; then
            mv "$conf_file" "${DIR_CONFIG}/${new_user}.conf"
            sed -i "s/Username=$user/Username=$new_user/g" "${DIR_CONFIG}/${new_user}.conf"
        fi
        echo -e "${GREEN}Sukses: Username '$user' telah diubah menjadi '$new_user'!${NC}"
        ;;
        
    2)
        echo -e "\n${CYAN}--- UBAH PASSWORD ---${NC}"
        read -p "Masukkan Password Baru : " new_pass
        if [[ -z "$new_pass" ]]; then
            echo -e "${RED}Password tidak boleh kosong!${NC}"; sleep 2; exit 1
        fi
        
        sed -i "/^\"*${user}\"*[[:space:]]\+pptpd[[:space:]]/d" "$FILE_SECRETS"
        echo "\"$user\" pptpd \"$new_pass\" * # Exp: $exp" >> "$FILE_SECRETS"
        
        echo -e "${GREEN}Sukses: Password untuk akun '$user' berhasil diperbarui!${NC}"
        ;;
        
    3)
        echo -e "\n${CYAN}--- PERPANJANG MASA AKTIF (RENEW) ---${NC}"
        echo -e "Masa Aktif saat ini : ${YELLOW}$exp${NC}"
        read -p "Tambah Masa Aktif (Hari) : " add_days
        
        if ! [[ "$add_days" =~ ^[0-9]+$ ]]; then
            echo -e "${RED}Gagal: Input harus berupa angka!${NC}"; sleep 2; exit 1
        fi
        
        # Logika Renew: Jika sudah kedaluwarsa, hitung dari hari ini. Jika belum, tambahkan dari exp.
        now=$(date +%Y-%m-%d)
        if [[ "$now" > "$exp" ]]; then
            new_exp=$(date -d "+${add_days} days" +"%Y-%m-%d")
        else
            new_exp=$(date -d "$exp + $add_days days" +"%Y-%m-%d")
        fi
        
        sed -i "/^\"*${user}\"*[[:space:]]\+pptpd[[:space:]]/d" "$FILE_SECRETS"
        echo "\"$user\" pptpd \"$old_pass\" * # Exp: $new_exp" >> "$FILE_SECRETS"
        
        if [ -f "$conf_file" ]; then
            sed -i "s/Expired=.*/Expired=$new_exp/g" "$conf_file"
        fi
        
        echo -e "${GREEN}Sukses: Masa aktif '$user' diperpanjang hingga $new_exp!${NC}"
        ;;
        
    0)
        echo -e "${YELLOW}Dibatalkan.${NC}"
        ;;
        
    *)
        echo -e "${RED}Pilihan tidak valid!${NC}"
        ;;
esac

echo ""
read -n 1 -s -r -p "Tekan [Enter] untuk kembali..."
