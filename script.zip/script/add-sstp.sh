#!/bin/bash
clear
read -p "Username Baru : " user

if grep -qw "^\"$user\"" /etc/ppp/chap-secrets || grep -qw "^$user" /etc/ppp/chap-secrets; then
    echo "❌ Username sudah ada! Silakan gunakan nama lain."
    exit 0
fi

read -p "Password      : " pass
read -p "Expired (Hari): " masaaktif

exp=$(date -d "+${masaaktif} days" +"%Y-%m-%d")
MYIP=$(curl -s ifconfig.me)

echo "\"$user\" * \"$pass\" * # Exp: $exp" >> /etc/ppp/chap-secrets

clear
echo "====================================================="
echo "                 AKUN SSTP BERHASIL DIBUAT           "
echo "====================================================="
echo "Protokol   : SSTP"
echo "IP Server  : $MYIP"
echo "Port       : 443"
echo "Username   : $user"
echo "Password   : $pass"
echo "Expired    : $exp"
echo "====================================================="
