#!/bin/bash
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'
purple="\033[1;95m"
y='\033[1;33m'

print_yellow() {
    echo -e "${y}$1${NC}"
}
FILE_SECRETS="/etc/ppp/chap-secrets"

while true; do
    clear
    print_yellow "════════════════════════════════════════════════════"
    echo -e "${CYAN}               MANAJEMEN AKUN L2TP                    ${NC}"
    print_yellow "        ══════════════════════════════════      "
    echo -e " ${GREEN}[1]${NC} Buat Akun Baru     (Create)"
    echo -e " ${GREEN}[2]${NC} Cek Detail Akun    (Read)"
    echo -e " ${GREEN}[3]${NC} Edit Akun          (Update/Renew)"
    echo -e " ${GREEN}[4]${NC} Hapus Akun         (Delete)"
    echo -e " ${GREEN}[5]${NC} Cek Status Online  (Status)"
    echo -e " ${RED}[0]${NC} Kembali ke Menu Utama"
    print_yellow "════════════════════════════════════════════════════"
    read -p " Masukkan Pilihan Anda [0-5] : " opt

    case $opt in
        1) bash /usr/bin/vpn-script/script/add-l2tp.sh ;;
        2) bash /usr/bin/vpn-script/script/cek-l2tp.sh ;;
        3) bash /usr/bin/vpn-script/script/edit-pptp.sh ;;
        4)
            echo -e "\n${CYAN}--- HAPUS AKUN L2TP ---${NC}"
            read -p "Masukkan Username : " user
            cek=$(awk -v u="$user" '($1 == u || $1 == "\""u"\"") && $2 == "xl2tpd"' "$FILE_SECRETS" | wc -l)
            if [ "$cek" -gt 0 ]; then
                sed -i "/^\"*${user}\"*[[:space:]]\+xl2tpd[[:space:]]/d" "$FILE_SECRETS"
                rm -f "/usr/bin/vpn-script/dashboard-user/config-l2tp/${user}.conf"
                echo -e "${GREEN}Sukses: Akun '$user' berhasil dihapus dari L2TP!${NC}"
            else
                echo -e "${RED}Gagal: Username '$user' tidak ditemukan di database L2TP!${NC}"
            fi
            echo ""
            read -n 1 -s -r -p "Tekan [Enter] untuk kembali..."
            ;;
        5) bash /usr/bin/vpn-script/script/status-l2tp.sh ;;
        0) clear; vpn; exit 0 ;;
        *) echo -e "\n${RED}Pilihan tidak valid, silakan coba lagi.${NC}"; sleep 2 ;;
    esac
done