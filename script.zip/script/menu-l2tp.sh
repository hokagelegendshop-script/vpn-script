#!/bin/bash
clear
echo -e "======================================"
echo -e "          MENU MANAJEMEN L2TP         "
echo -e "======================================"
echo -e "1. Buat Akun L2TP/PPTP Baru"
echo -e "2. Hapus Akun L2TP/PPTP"
echo -e "3. Perpanjang Masa Aktif L2TP/PPTP"
echo -e "4. Cek Pengguna L2TP/PPTP Aktif"
echo -e "5. Kembali ke Menu Utama"
echo -e "6. Keluar"
echo -e "======================================"
read -p "Pilih menu (1-6): " option

case $option in
    1)
        /usr/bin/vpn-script/script/add-l2tp.sh
        ;;
    2)
        /usr/bin/vpn-script/script/del-l2tp.sh
        ;;
    3)
        /usr/bin/vpn-script/script/renew-l2tp.sh
        ;;
    4)
        /usr/bin/vpn-script/script/cek-l2tp.sh
        ;;
    5)
        /usr/bin/vpn-script/script/menu.sh
        ;;
    6)
        clear
        exit 0
        ;;
    *)
        echo "❌ Pilihan tidak valid!"
        sleep 2
        /usr/bin/vpn-script/script/menu-l2tp.sh
        ;;
esac
