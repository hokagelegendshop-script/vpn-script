#!/bin/bash

# ==========================================================
# WG-CRON: Auto Check Expired & Kuota (Megabytes)
# ==========================================================

today=$(date +%Y-%m-%d)
wg_conf="/etc/wireguard/wg0.conf"

# Membaca seluruh klien yang memiliki tag aktif "### Client"
grep "^### Client" "$wg_conf" | while read -r line; do
    user=$(echo "$line" | awk '{print $3}')
    exp_date=$(echo "$line" | awk '{print $4}')
    limit_ip=$(echo "$line" | awk '{print $5}')
    limit_quota=$(echo "$line" | awk '{print $6}')

    # Menarik PublicKey klien tersebut untuk pencocokan di memori kernel
    pubkey=$(grep -A 2 "^### Client $user\b" "$wg_conf" | grep "PublicKey" | awk '{print $3}')
    
    # ------------------------------------------------------
    # 1. PENGECEKAN MASA AKTIF (EXPIRED)
    # ------------------------------------------------------
    if [[ "$today" > "$exp_date" ]]; then
        # Cabut akses dari memori secara live tanpa restart
        wg set wg0 peer "$pubkey" remove
        # Ubah label di database agar tidak diload ulang saat server reboot
        sed -i "s/^### Client $user/### Expired $user/" "$wg_conf"
        continue
    fi

    # ------------------------------------------------------
    # 2. PENGECEKAN KUOTA (MEGABYTES)
    # ------------------------------------------------------
    # Abaikan pengecekan jika limit diatur ke 0 (Unlimited)
    if [ "$limit_quota" -gt 0 ]; then
        # Menarik data konsumsi langsung dari kernel WireGuard
        traffic=$(wg show wg0 transfer | grep "$pubkey")
        
        if [ -n "$traffic" ]; then
            rx_bytes=$(echo "$traffic" | awk '{print $2}')
            tx_bytes=$(echo "$traffic" | awk '{print $3}')
            
            total_bytes=$((rx_bytes + tx_bytes))
            # Konversi matematis byte ke Megabytes
            total_mb=$((total_bytes / 1024 / 1024))
            
            if [ "$total_mb" -ge "$limit_quota" ]; then
                # Cabut akses karena batas Megabytes terlampaui
                wg set wg0 peer "$pubkey" remove
                sed -i "s/^### Client $user/### QuotaExceeded $user/" "$wg_conf"
            fi
        fi
    fi
    
    # ------------------------------------------------------
    # 3. PENGECEKAN LIMIT IP / DEVICE
    # ------------------------------------------------------
    # Catatan: WireGuard adalah protokol "Stateless". Berbeda dengan SSH/SSTP, ia tidak 
    # memiliki sesi login aktif yang bisa dihitung. Jika dua IP menggunakan config yang 
    # sama secara bersamaan, mereka hanya akan berebut koneksi (koneksi putus-nyambung).
    # Parameter Limit IP disimpan murni untuk kebutuhan database panel web/billing Anda.
done
