#!/bin/bash

# ==========================================
# Definisi Warna untuk Indikator
# ==========================================
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# File database pengguna PPTP
FILE_SECRETS="/etc/ppp/chap-secrets"

while true; do
    clear
    echo -e "${CYAN}======================================================${NC}"
    echo -e "${YELLOW}               MANAJEMEN AKUN PPTP                    ${NC}"
    echo -e "${CYAN}======================================================${NC}"
    echo -e " ${GREEN}[1]${NC} Buat Akun Baru     (Create)"
    echo -e " ${GREEN}[2]${NC} Lihat Daftar Akun  (Read)"
    echo -e " ${GREEN}[3]${NC} Ubah Password Akun (Update)"
    echo -e " ${GREEN}[4]${NC} Hapus Akun         (Delete)"
    echo -e " ${RED}[0]${NC} Kembali ke Menu Utama"
    echo -e "${CYAN}======================================================${NC}"
    read -p " Masukkan Pilihan Anda [0-4] : " opt

    case $opt in
        1)
            echo -e "\n${CYAN}--- BUAT AKUN PPTP BARU ---${NC}"
            read -p "Masukkan Username : " user
            
            # Cek apakah username sudah ada (kata pertama di setiap baris)
            if grep -qw "^$user" "$FILE_SECRETS"; then
                echo -e "${RED}Gagal: Username '$user' sudah terdaftar!${NC}"
            else
                read -p "Masukkan Password : " pass
                # Format PPTP: username * password *
                echo "$user * $pass *" >> "$FILE_SECRETS"
                echo -e "${GREEN}Sukses: Akun '$user' berhasil dibuat!${NC}"
            fi
            echo ""
            read -p "Tekan [Enter] untuk kembali..."
            ;;
            
        2)
            echo -e "\n${CYAN}--- DAFTAR AKUN PPTP ---${NC}"
            echo -e "--------------------------------------------------"
            printf "%-20s | %-20s\n" "USERNAME" "PASSWORD"
            echo -e "--------------------------------------------------"
            
            # Membaca file chap-secrets, mengabaikan baris kosong dan komentar (#)
            grep -v "^#" "$FILE_SECRETS" | grep -v "^$" | while read -r usr server pass ip; do
                printf "%-20s | %-20s\n" "$usr" "$pass"
            done
            
            echo -e "--------------------------------------------------"
            echo ""
            read -p "Tekan [Enter] untuk kembali..."
            ;;
            
        3)
            echo -e "\n${CYAN}--- UBAH PASSWORD AKUN PPTP ---${NC}"
            read -p "Masukkan Username : " user
            
            if grep -qw "^$user" "$FILE_SECRETS"; then
                read -p "Masukkan Password Baru : " pass
                # Hapus baris lama berdasarkan username
                sed -i "/^$user\s/d" "$FILE_SECRETS"
                # Masukkan baris baru dengan password baru
                echo "$user * $pass *" >> "$FILE_SECRETS"
                echo -e "${GREEN}Sukses: Password untuk '$user' berhasil diubah!${NC}"
            else
                echo -e "${RED}Gagal: Username '$user' tidak ditemukan!${NC}"
            fi
            echo ""
            read -p "Tekan [Enter] untuk kembali..."
            ;;
            
        4)
            echo -e "\n${CYAN}--- HAPUS AKUN PPTP ---${NC}"
            read -p "Masukkan Username : " user
            
            if grep -qw "^$user" "$FILE_SECRETS"; then
                # Hapus baris yang diawali dengan username tersebut beserta spasinya
                sed -i "/^$user\s/d" "$FILE_SECRETS"
                echo -e "${GREEN}Sukses: Akun '$user' berhasil dihapus!${NC}"
            else
                echo -e "${RED}Gagal: Username '$user' tidak ditemukan!${NC}"
            fi
            echo ""
            read -p "Tekan [Enter] untuk kembali..."
            ;;
            
        0)
            clear
            # Kembali ke script menu utama
            panelvpn
            exit 0
            ;;
            
        *)
            echo -e "\n${RED}Pilihan tidak valid, silakan coba lagi.${NC}"
            sleep 2
            ;;
    esac
done