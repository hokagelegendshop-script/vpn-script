#!/bin/bash

# ==========================================
# Definisi Warna untuk Indikator
# ==========================================
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'
purple="\033[1;95m"
y='\033[1;33m'

print_yellow() {
    echo -e "${y}$1${NC}"
}

# ==========================================
# LISENSI & PERMISSION CHECKER
# ==========================================
ipsaya=$(curl -sSL ifconfig.me | tr -d '\n' | tr -d '\r' | tr -d ' ')
izinsc="https://github.com/hokagelegendshop-script/aksses/raw/refs/heads/main/permission"

checking_sc() {
    get_permission=$(curl -sSL "$izinsc")
    cek_ip=$(echo "$get_permission" | grep -w "$ipsaya")
    
    if [[ -z "$cek_ip" ]]; then
        clear
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        echo -e "\033[41m          404 NOT FOUND AUTOSCRIPT          \033[0m"
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        echo -e " IP VPS Anda : $ipsaya"
        echo -e " Status      : TIDAK TERDAFTAR!"
        echo -e " Silakan hubungi Admin untuk membeli skrip."
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        exit 1
    fi
    
    client_name=$(echo "$cek_ip" | awk '{print $2}')
    useexp=$(echo "$cek_ip" | awk '{print $3}')
    status_onoff=$(echo "$cek_ip" | awk '{print $5}')
    today=$(date +%Y-%m-%d)
    
    if [[ "$status_onoff" != "ON" ]]; then
        clear
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        echo -e "\033[41m              SCRIPT DISABLED               \033[0m"
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        echo -e " IP VPS Anda : $ipsaya"
        echo -e " Klien       : $client_name"
        echo -e " Status      : DIBLOKIR / SUSPEND"
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        exit 1
    fi
    
    if [[ "$today" > "$useexp" ]]; then
        clear
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        echo -e "\033[41m          SCRIPT EXPIRED / KADALUARSA       \033[0m"
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        echo -e " IP VPS Anda : $ipsaya"
        echo -e " Klien       : $client_name"
        echo -e " Expired     : $useexp"
        echo -e " Silakan hubungi Admin untuk perpanjangan."
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        exit 1
    fi
    
    echo "$useexp" > /etc/vps-expired
    echo "$client_name" > /etc/vps-client
}

checking_sc

# ==========================================
# Mengambil Informasi Sistem
# ==========================================
os_name=$(cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/PRETTY_NAME=//g' | sed 's/"//g')
isp_name=$(curl -s ipinfo.io/org)
city_name=$(curl -s ipinfo.io/city)
uptime_info=$(uptime -p | cut -d " " -f 2-10)

if [ -f /etc/xray/domain ]; then
    domain_name=$(cat /etc/xray/domain)
else
    domain_name="id.hokagelegend.net"
fi

if [ -f /etc/vps-expired ]; then
    exp_date=$(cat /etc/vps-expired)
    client_owner=$(cat /etc/vps-client 2>/dev/null || echo "Unknown")
    sisa_hari=$(( ($(date -d "$exp_date" +%s) - $(date +%s)) / 86400 ))
    exp_info="$exp_date (${sisa_hari} Hari) (Active)"
else
    exp_info="Lifetime (Active)"
    client_owner="Lifetime User"
fi

ram_total=$(free -m | awk 'NR==2 {print $2}')
ram_used=$(free -m | awk 'NR==2 {print $3}')
ram_info="${ram_used} MB / ${ram_total} MB"
cpu_cores=$(nproc)
cpu_info="${cpu_cores} Core(s)"

# ==========================================
# Menghitung Total User (Diperbaiki)
# ==========================================
total_wg=$(grep '^### Client' /etc/wireguard/wg0.conf 2>/dev/null | wc -l)
total_ppp=$(grep -vE '^#|^$' /etc/ppp/chap-secrets 2>/dev/null | wc -l)

# ==========================================
# Fungsi Cek Status Layanan
# ==========================================
if systemctl is-active --quiet wg-quick@wg0; then
    status_wg="${GREEN}🟢 ONLINE${NC}"
else
    status_wg="${RED}🔴 OFFLINE${NC}"
fi

if systemctl is-active --quiet xl2tpd && systemctl is-active --quiet ipsec; then
    status_l2tp="${GREEN}🟢 ONLINE${NC}"
else
    status_l2tp="${RED}🔴 OFFLINE${NC}"
fi

if systemctl is-active --quiet pptpd; then
    status_pptp="${GREEN}🟢 ONLINE${NC}"
else
    status_pptp="${RED}🔴 OFFLINE${NC}"
fi

# ==========================================
# Tampilan Menu Utama
# ==========================================
clear
echo -e ""
print_yellow "════════════════════════════════════════════════════"
echo -e "${YELLOW}System OS      = ${CYAN}$os_name${NC}"
echo -e "${YELLOW}Public IP      = ${CYAN}$ipsaya${NC}"
echo -e "${YELLOW}CPU Cores      = ${CYAN}$cpu_info${NC}"
echo -e "${YELLOW}RAM Usage      = ${CYAN}$ram_info${NC}"
echo -e "${YELLOW}ISP            = ${CYAN}$isp_name${NC}"
echo -e "${YELLOW}City           = ${CYAN}$city_name${NC}"
echo -e "${YELLOW}Uptime         = ${CYAN}$uptime_info${NC}"
echo -e "${YELLOW}Client Name    = ${GREEN}$client_owner${NC}"
echo -e "${YELLOW}Expired        = ${GREEN}$exp_info${NC}"
echo -e "${YELLOW}Domain         = ${CYAN}$domain_name${NC}"
print_yellow "════════════════════════════════════════════════════"
echo -e "${YELLOW}         HOKAGE LEGEND VPN DASHBOARD             ${NC}"
print_yellow "════════════════════════════════════════════════════"
echo -e "              ${CYAN}STATUS SERVICE VPN: ${NC}                "
print_yellow "      ══════════════════════════════════      "
echo -e " WireGuard   : $status_wg ( $total_wg User )"
echo -e " PPTP        : $status_pptp ( $total_ppp User )"
echo -e " L2TP        : $status_l2tp ( $total_ppp User )"
print_yellow "════════════════════════════════════════════════════"
echo -e "              ${purple}MANAGEMENT ACCOUNT: ${NC}                "
print_yellow "      ══════════════════════════════════      "
echo -e "${GREEN}[1]${NC} Menu WireGuard         ${GREEN}[6]${NC} Restart All Service ${NC}"
echo -e "${GREEN}[2]${NC} Menu PPTP      "
echo -e "${GREEN}[3]${NC} Menu L2TP      "
echo -e "${GREEN}[4]${NC} Menu Bot Telegram "
echo -e "${GREEN}[5]${NC} Update Script VPN "
echo -e "${RED}[0]${NC} Keluar"
print_yellow "════════════════════════════════════════════════════"
read -p " Masukkan Pilihan Anda [0-6] : " opt

case $opt in
    1) clear; bash /usr/bin/vpn-script/script/menu-wg.sh ;;
    2) clear; bash /usr/bin/vpn-script/script/menu-pptp.sh ;;
    3) clear; bash /usr/bin/vpn-script/script/menu-l2tp.sh ;;
    4) clear; bash /usr/bin/vpn-script/script/menu-bot.sh ;;
    5) 
        clear
        echo -e "${YELLOW}Menghubungkan ke Server Update...${NC}"
        
        # Pindah ke /tmp agar eksekusi bersih
        cd /tmp
        rm -f update
        
        # Mengunduh skrip 'update' dari GitHub (menggunakan RAW link)
        wget -qO update "https://github.com/hokagelegendshop-script/vpn-script/raw/refs/heads/main/update"
        
        # Eksekusi skrip update jika berhasil diunduh
        if [ -s update ]; then
            chmod +x update
            bash update
            rm -f update
        else
            echo -e "${RED}Gagal terhubung ke Server Update! Periksa koneksi atau URL GitHub Anda.${NC}"
            sleep 3
            vpn
        fi
        ;;
    6) clear; restart-vpn ;;
    0) clear; echo -e "${GREEN}Keluar dari VPN Dashboard...${NC}"; exit 0 ;;
    *) echo -e "${RED}Pilihan tidak valid!${NC}"; sleep 2; vpn ;;
esac