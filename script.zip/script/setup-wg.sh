#!/bin/bash

# 1. Update sistem dan install dependensi WireGuard
echo "Memulai instalasi WireGuard..."
apt-get update -y
apt-get install -y wireguard iptables resolvconf qrencode

# 2. Mengaktifkan IPv4 Forwarding (Wajib untuk VPN)
echo "Mengonfigurasi IP Forwarding..."
sed -i '/net.ipv4.ip_forward/d' /etc/sysctl.conf
echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
sysctl -p

# 3. Mendeteksi interface jaringan publik secara otomatis (misal: eth0 atau ens3)
SERVER_PUB_NIC=$(ip -4 route ls | grep default | grep -Po '(?<=dev )(\S+)' | head -1)

# 4. Membuat direktori WireGuard dan meng-generate Server Keys
echo "Menghasilkan Private dan Public Key Server..."
mkdir -p /etc/wireguard
chmod 0777 /etc/wireguard
cd /etc/wireguard
wg genkey | tee server_private_key | wg pubkey > server_public_key
SERVER_PRIV_KEY=$(cat server_private_key)

# 5. Membuat file konfigurasi utama WireGuard (wg0.conf)
echo "Membuat konfigurasi wg0.conf..."
cat < /etc/wireguard/wg0.conf
[Interface]
Address = 10.66.66.1/24
ListenPort = 51820
PrivateKey = $SERVER_PRIV_KEY
PostUp = iptables -A FORWARD -i wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o $SERVER_PUB_NIC -j MASQUERADE
PostDown = iptables -D FORWARD -i wg0 -j ACCEPT; iptables -t nat -D POSTROUTING -o $SERVER_PUB_NIC -j MASQUERADE
EOF

# 6. Mengatur hak akses file agar aman
chmod 600 /etc/wireguard/wg0.conf
chmod 600 /etc/wireguard/server_private_key

# 7. Mengaktifkan dan menjalankan service WireGuard
echo "Menjalankan service wg-quick@wg0..."
systemctl enable wg-quick@wg0
systemctl start wg-quick@wg0
systemctl restart wg-quick@wg0

# 8. Selesai
clear
echo "================================================="
echo "       INSTALASI WIREGUARD SELESAI               "
echo "================================================="
echo " - Interface Jaringan : $SERVER_PUB_NIC"
echo " - Port WireGuard     : 51820"
echo " - Subnet IP          : 10.66.66.1/24"
echo "================================================="
