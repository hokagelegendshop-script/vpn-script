#!/bin/bash
clear

# Warna
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${CYAN}======================================================${NC}"
echo -e "${YELLOW}               CEK USER WIREGUARD ONLINE              ${NC}"
echo -e "${CYAN}======================================================${NC}"
printf " %-12s | %-14s | %-15s\n" "Username" "IP Client" "Status"
echo -e "${CYAN}------------------------------------------------------${NC}"

now=$(date +%s)
wg_conf="/etc/wireguard/wg0.conf"

# Membaca file konfigurasi untuk mencocokkan PublicKey dengan Username
grep "^### Client" "$wg_conf" | while read -r line; do
    user=$(echo "$line" | awk '{print $3}')
    pubkey=$(grep -A 2 "^### Client $user\b" "$wg_conf" | grep "PublicKey" | awk '{print $3}')
    client_ip=$(grep -A 3 "^### Client $user\b" "$wg_conf" | grep "AllowedIPs" | awk '{print $3}' | cut -d'/' -f1)
    
    # Mendapatkan waktu handshake terakhir (dalam epoch)
    handshake=$(wg show wg0 latest-handshakes | grep "$pubkey" | awk '{print $2}')
    
    if [[ -n "$handshake" && "$handshake" != "0" ]]; then
        diff=$((now - handshake))
        # Jika handshake terakhir terjadi kurang dari 3 menit (180 detik) yang lalu
        if [[ $diff -lt 180 ]]; then
            status="${GREEN}ONLINE${NC}"
        else
            status="${RED}OFFLINE${NC}"
        fi
    else
        status="${RED}OFFLINE${NC}"
    fi
    
    printf " %-12s | %-14s | %b\n" "$user" "$client_ip" "$status"
done

echo -e "${CYAN}======================================================${NC}"
echo ""
read -n 1 -s -r -p "Tekan tombol apapun untuk kembali ke menu..."
bash /usr/bin/vpn-script/script/menu-wg.sh
