#!/bin/bash
clear
# ==========================================
# Definisi Warna untuk Indikator
# ==========================================
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color
purple="\033[1;95m"
y='\033[1;33m' #yellow

print_yellow() {
    echo -e "${y}$1${NC}"
}

print_yellow "════════════════════════════════════════════════════"
echo -e "${purple}          CEK USER WIREGUARD ONLINE              ${NC}"
print_yellow "       ══════════════════════════════════      "
echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
printf " %-12s | %-14s | %-15s\n" "Username" "IP Client" "Status"
echo -e "${CYAN}════════════════════════════════════════════════════${NC}"

now=$(date +%s)
wg_conf="/etc/wireguard/wg0.conf"

# Membaca file konfigurasi untuk mencocokkan PublicKey dengan Username
grep "^### Client" "$wg_conf" | while read -r line; do
    user=$(echo "$line" | awk '{print $3}')
    
    # Ditingkatkan menjadi -A 4 agar tidak luput jika ada PresharedKey
    pubkey=$(grep -A 4 "^### Client $user\b" "$wg_conf" | grep "PublicKey" | awk '{print $3}' | head -n 1)
    
    # Ditingkatkan menjadi -A 5 agar AllowedIPs terbaca dengan sempurna
    client_ip=$(grep -A 5 "^### Client $user\b" "$wg_conf" | grep "AllowedIPs" | awk '{print $3}' | cut -d'/' -f1 | head -n 1)
    
    # Mendapatkan waktu handshake terakhir (dalam epoch)
    handshake=$(wg show wg0 latest-handshakes | grep "$pubkey" | awk '{print $2}')
    
    if [[ -n "$handshake" && "$handshake" != "0" ]]; then
        diff=$((now - handshake))
        # Jika handshake terakhir terjadi kurang dari 3 menit (180 detik) yang lalu
        if [[ $diff -lt 180 ]]; then
            status="${GREEN}ONLINE${NC}"
        else
            status="${RED}OFFLINE${NC}"
        fi
    else
        status="${RED}OFFLINE${NC}"
    fi
    
    printf " %-12s | %-14s | %b\n" "$user" "$client_ip" "$status"
done

print_yellow "════════════════════════════════════════════════════"
echo ""
read -n 1 -s -r -p "Tekan tombol apapun untuk kembali ke menu..."
bash /usr/bin/vpn-script/script/menu-wg.sh