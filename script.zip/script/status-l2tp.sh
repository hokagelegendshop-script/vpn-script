#!/bin/bash
clear

GREEN='\033[0;32m'
RED='\033[0;31m'
CYAN='\033[0;36m'
purple='\033[1;95m'
NC='\033[0m'

FILE_SECRETS="/etc/ppp/chap-secrets"

echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
echo -e "${purple}               STATUS ONLINE AKUN L2TP              ${NC}"
echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
printf " %-20s | %-15s\n" "USERNAME" "STATUS"
echo -e "--------------------------------------------------------"

# Membaca username dari database L2TP
awk '$2 == "xl2tpd" {print $1}' "$FILE_SECRETS" | tr -d '"' | while read -r usr; do
    
    # Mencocokkan nama user dengan data tracker dari ip-up.d
    if grep -qx "$usr" /var/run/ppp-*.user 2>/dev/null; then
        status="${GREEN}ONLINE${NC}"
    else
        status="${RED}OFFLINE${NC}"
    fi
    printf " %-20s | %b\n" "$usr" "$status"
done

echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
echo ""
read -n 1 -s -r -p "Tekan [Enter] untuk kembali..."