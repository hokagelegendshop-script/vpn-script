#!/bin/bash
clear
echo -e "\033[0;36m======================================================\033[0m"
echo -e "\033[1;33m             RESTART ALL VPN SERVICES                 \033[0m"
echo -e "\033[0;36m======================================================\033[0m"
echo -e "\033[0;32m[+]\033[0m Restarting WireGuard..."
systemctl restart wg-quick@wg0
echo -e "\033[0;32m[+]\033[0m Restarting L2TP & IPSec..."
systemctl restart xl2tpd
systemctl restart ipsec
echo -e "\033[0;32m[+]\033[0m Restarting PPTP..."
systemctl restart pptpd
echo -e "\033[0;32m[+]\033[0m Restarting Hokage Bot Telegram..."
systemctl restart hokage-bot
echo -e "\033[0;32m[+]\033[0m Restarting Cronjobs Auto-Kill..."
systemctl restart cron
echo -e "\033[0;36m======================================================\033[0m"
echo -e "\033[1;32m✅ SEMUA SERVICE BERHASIL DI-RESTART!\033[0m"
echo -e "\033[0;36m======================================================\033[0m"
sleep 3
vpn
