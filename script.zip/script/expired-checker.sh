#!/bin/bash
today=$(date +%Y-%m-%d)

# Pengecekan WireGuard
wg_conf="/etc/wireguard/wg0.conf"
grep "^### Client" "$wg_conf" | while read -r line; do
    user=$(echo "$line" | awk '{print $3}')
    exp_date=$(echo "$line" | awk '{print $4}')
    pubkey=$(grep -A 2 "^### Client $user\b" "$wg_conf" | grep "PublicKey" | awk '{print $3}')
    
    if [[ "$today" > "$exp_date" ]]; then
        wg set wg0 peer "$pubkey" remove
        sed -i "s/^### Client $user/### Expired $user/" "$wg_conf"
    fi
done

# Pengecekan L2TP dan PPTP (Berbagi chap-secrets)
ppp_conf="/etc/ppp/chap-secrets"
grep -E "^\"[^\"]+\" \* \"[^\"]+\" \* # Exp: [0-9]{4}-[0-9]{2}-[0-9]{2}" "$ppp_conf" | while read -r line; do
    exp_date=$(echo "$line" | grep -oP 'Exp: \K\d{4}-\d{2}-\d{2}')
    user=$(echo "$line" | awk -F'"' '{print $2}')
    
    if [[ "$today" > "$exp_date" ]]; then
        # Hapus dari database
        sed -i "/^\"$user\" /d" "$ppp_conf"
        # Putuskan koneksi jika user sedang terhubung
        kill $(ps -ef | grep pppd | grep -w "$user" | awk '{print $2}') 2>/dev/null
    fi
done
