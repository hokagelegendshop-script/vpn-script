#!/bin/bash
# ==========================================
# AUTO-KILL EXPIRED ACCOUNTS (WG, PPTP, L2TP)
# Dieksekusi otomatis oleh Cronjob jam 00:10
# ==========================================
today=$(date +%Y-%m-%d)

# 1. HAPUS AKUN PPTP EXPIRED
DIR_PPTP="/usr/bin/vpn-script/dashboard-user/config-pptp"
if [ -d "$DIR_PPTP" ]; then
    for conf in "$DIR_PPTP"/*.conf; do
        [ -f "$conf" ] || continue
        user=$(grep "^Username=" "$conf" | cut -d= -f2)
        exp=$(grep "^Expired=" "$conf" | cut -d= -f2)
        
        # Jika tanggal hari ini lebih besar dari tanggal expired
        if [[ "$today" > "$exp" ]]; then
            # Hapus dari database chap-secrets
            sed -i "/^\"*${user}\"*[[:space:]]\+pptpd[[:space:]]/d" /etc/ppp/chap-secrets
            # Hapus file konfigurasi limit
            rm -f "$conf"
            # Putuskan paksa jika user sedang online
            for pid in $(pgrep pppd); do
                auth_user=$(journalctl _PID=$pid --no-pager 2>/dev/null | grep -i "peer" | grep -i "authenticated" | tail -n 1 | grep -Po '(?<=peer )[^ ]+' | tr -d "'\"")
                if [[ "$auth_user" == "$user" ]]; then
                    kill -9 $pid 2>/dev/null
                fi
            done
        fi
    done
fi

# 2. HAPUS AKUN L2TP EXPIRED
DIR_L2TP="/usr/bin/vpn-script/dashboard-user/config-l2tp"
if [ -d "$DIR_L2TP" ]; then
    for conf in "$DIR_L2TP"/*.conf; do
        [ -f "$conf" ] || continue
        user=$(grep "^Username=" "$conf" | cut -d= -f2)
        exp=$(grep "^Expired=" "$conf" | cut -d= -f2)
        
        if [[ "$today" > "$exp" ]]; then
            sed -i "/^\"*${user}\"*[[:space:]]\+xl2tpd[[:space:]]/d" /etc/ppp/chap-secrets
            sed -i "/^\"*${user}\"*[[:space:]]\+l2tpd[[:space:]]/d" /etc/ppp/chap-secrets
            rm -f "$conf"
        fi
    done
fi

# 3. HAPUS AKUN WIREGUARD EXPIRED
wg_conf="/etc/wireguard/wg0.conf"
if [ -f "$wg_conf" ]; then
    grep "^### Client" "$wg_conf" | while read -r line; do
        user=$(echo "$line" | awk '{print $3}')
        exp_date=$(echo "$line" | awk '{print $4}')
        pubkey=$(grep -A 4 "^### Client $user\b" "$wg_conf" | grep "PublicKey" | awk '{print $3}' | head -n 1)
        
        if [[ "$today" > "$exp_date" ]]; then
            wg set wg0 peer "$pubkey" remove
            # Hapus blok konfigurasi user dari file wg0.conf
            sed -i "/^### Client $user $exp_date/,/^AllowedIPs/d" "$wg_conf"
        fi
    done
fi