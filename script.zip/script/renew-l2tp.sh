#!/bin/bash
clear
read -p "Username yang akan diperpanjang: " user

if ! grep -qw "^\"$user\"" /etc/ppp/chap-secrets && ! grep -qw "^$user" /etc/ppp/chap-secrets; then
    echo "❌ Username tidak ditemukan di database!"
    exit 0
fi

read -p "Tambahan masa aktif (Hari): " masaaktif

# Ekstrak data akun yang lama (dukung format kutip/tanpa kutip)
user_line=$(grep -E "^\"?$user\"? " /etc/ppp/chap-secrets | head -n 1)
pass=$(echo "$user_line" | awk -F'*' '{print $2}' | tr -d ' ' | tr -d '"')
exp_date=$(echo "$user_line" | awk -F'Exp: ' '{print $2}' | tr -d ' ')

if [[ -z "$exp_date" ]]; then
    exp_date=$(date +"%Y-%m-%d")
fi

new_exp=$(date -d "$exp_date + $masaaktif days" +"%Y-%m-%d")

# Hapus baris lama dan timpa dengan yang baru
sed -i "/^\"$user\" /d" /etc/ppp/chap-secrets
sed -i "/^$user /d" /etc/ppp/chap-secrets
echo "\"$user\" * \"$pass\" * # Exp: $new_exp" >> /etc/ppp/chap-secrets

echo "✅ Akun '$user' berhasil diperpanjang hingga $new_exp!"
