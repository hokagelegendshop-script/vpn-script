#!/bin/bash
clear
echo -e "======================================"
echo -e "          MENU MANAJEMEN SSTP         "
echo -e "======================================"
echo -e "1. Buat Akun SSTP Baru"
echo -e "2. Hapus Akun SSTP"
echo -e "3. Perpanjang Masa Aktif SSTP"
echo -e "4. Cek Pengguna SSTP Aktif"
echo -e "5. Kembali ke Menu Utama"
echo -e "6. Keluar"
echo -e "======================================"
read -p "Pilih menu (1-6): " option

case $option in
    1) /usr/bin/vpn-script/script/add-sstp.sh ;;
    2) /usr/bin/vpn-script/script/del-sstp.sh ;;
    3) /usr/bin/vpn-script/script/renew-sstp.sh ;;
    4) /usr/bin/vpn-script/script/cek-sstp.sh ;;
    5) /usr/bin/vpn-script/script/menu.sh ;;
    6) clear; exit 0 ;;
    *) echo "❌ Pilihan tidak valid!"; sleep 2; /usr/bin/vpn-script/script/menu-sstp.sh ;;
esac
