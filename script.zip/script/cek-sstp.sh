#!/bin/bash
clear
echo "======================================"
echo "        CEK DETAIL AKUN SSTP          "
echo "======================================"

mapfile -t list_users < <(grep -vE "^#|^$" /etc/ppp/chap-secrets | awk '{print $1}' | sed 's/"//g')

if [ ${#list_users[@]} -eq 0 ]; then
    echo "❌ Belum ada pengguna yang terdaftar."
    echo "======================================"
    exit 0
fi

for i in "${!list_users[@]}"; do
    nomor=$((i + 1))
    exp=$(grep -E "^\"?${list_users[$i]}\"? " /etc/ppp/chap-secrets | head -n 1 | awk -F'Exp: ' '{print $2}' | tr -d ' ')
    [[ -z "$exp" ]] && exp="Tidak Terbatas"
    echo "$nomor. ${list_users[$i]} (Exp: $exp)"
done
echo "======================================"
read -p "Cek detail akun (Masukkan Nomor/Username): " input_user

target_user=""
if [[ "$input_user" =~ ^[0-9]+$ ]] && [ "$input_user" -ge 1 ] && [ "$input_user" -le ${#list_users[@]} ]; then
    idx=$((input_user - 1))
    target_user="${list_users[$idx]}"
else
    for u in "${list_users[@]}"; do
        if [ "$u" == "$input_user" ]; then
            target_user="$input_user"
            break
        fi
    done
fi

if [ -z "$target_user" ]; then
    echo "❌ Nomor atau Username tidak ditemukan!"
    exit 0
fi

user_line=$(grep -E "^\"?$target_user\"? " /etc/ppp/chap-secrets | head -n 1)
pass=$(echo "$user_line" | awk '{print $3}' | tr -d '"')
exp_date=$(echo "$user_line" | awk -F'Exp: ' '{print $2}' | tr -d ' ')
[[ -z "$exp_date" ]] && exp_date="Tidak Terbatas"

MYIP=$(curl -s ifconfig.me)

clear
echo "====================================================="
echo "                  DETAIL AKUN SSTP                   "
echo "====================================================="
echo "Protokol   : SSTP"
echo "IP Server  : $MYIP"
echo "Port       : 443"
echo "Username   : $target_user"
echo "Password   : $pass"
echo "Expired    : $exp_date"
echo "====================================================="
