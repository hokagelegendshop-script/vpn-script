#!/bin/bash
clear
# ==========================================
# Definisi Warna untuk Indikator
# ==========================================
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'
purple="\033[1;95m"
y='\033[1;33m'

print_yellow() {
    echo -e "${y}$1${NC}"
}

# ==========================================
# LISENSI & PERMISSION CHECKER
# ==========================================
ipsaya=$(curl -sSL ifconfig.me | tr -d '\n' | tr -d '\r' | tr -d ' ')
izinsc="https://github.com/hokagelegendshop-script/aksses/raw/refs/heads/main/permission"

checking_sc() {
    get_permission=$(curl -sSL "$izinsc")
    cek_ip=$(echo "$get_permission" | grep -w "$ipsaya")
    if [[ -z "$cek_ip" ]]; then
        clear; echo -e "\033[41m 404 NOT FOUND AUTOSCRIPT \033[0m"; exit 1
    fi
}
checking_sc

# Cek Status Bot
if systemctl is-active --quiet hokage-bot; then
    status_bot="${GREEN}🟢 RUNNING${NC}"
else
    status_bot="${RED}🔴 STOPPED${NC}"
fi

clear
print_yellow "════════════════════════════════════════════════════"
echo -e "${YELLOW}           MANAGEMENT BOT TELEGRAM              ${NC}"
print_yellow "      ══════════════════════════════════      "
echo -e "  Status Bot : $status_bot"
print_yellow "      ══════════════════════════════════      "
echo -e "  \033[0;32m[1]\033[0m Restart Bot Telegram"
echo -e "  \033[0;32m[2]\033[0m Cek Log / Error Bot (Live)"
echo -e "  \033[0;32m[3]\033[0m Edit Token & ID Admin"
echo -e "  \033[0;31m[4]\033[0m Matikan Bot (Stop)"
echo -e "  \033[0;31m[0]\033[0m Kembali ke Menu Utama"
echo -e "\033[0;36m======================================================\033[0m"
read -p " Masukkan Pilihan Anda [0-4] : " bot_opt

case $bot_opt in
    1) 
        echo -e "${CYAN}Me-restart layanan bot...${NC}"
        systemctl restart hokage-bot
        sleep 2
        bash /usr/bin/vpn-script/script/menu-bot.sh
        ;;
    2) 
        clear
        echo -e "${YELLOW}Menampilkan 30 baris log terakhir Bot Telegram:${NC}"
        echo "---------------------------------------------------"
        journalctl -u hokage-bot -n 30 --no-pager
        echo "---------------------------------------------------"
        read -n 1 -s -r -p "Tekan tombol apapun untuk kembali..."
        bash /usr/bin/vpn-script/script/menu-bot.sh
        ;;
    3) 
        nano /usr/bin/vpn-script/bot-telegram/config.py
        echo -e "${CYAN}Menyimpan perubahan dan me-restart bot...${NC}"
        systemctl restart hokage-bot
        sleep 2
        bash /usr/bin/vpn-script/script/menu-bot.sh
        ;;
    4)
        echo -e "${RED}Mematikan layanan bot...${NC}"
        systemctl stop hokage-bot
        sleep 2
        bash /usr/bin/vpn-script/script/menu-bot.sh
        ;;
    0) 
        vpn 
        ;;
    *) 
        echo "Pilihan tidak valid!"
        sleep 2
        bash /usr/bin/vpn-script/script/menu-bot.sh
        ;;
esac
