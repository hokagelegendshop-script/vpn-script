#!/bin/bash
clear
# ==========================================
# Definisi Warna untuk Indikator
# ==========================================
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color
purple="\033[1;95m"
y='\033[1;33m' #yellow

print_yellow() {
    echo -e "${y}$1${NC}"
}

# ==========================================
# LISENSI & PERMISSION CHECKER
# ==========================================
ipsaya=$(curl -sSL ifconfig.me | tr -d '\n' | tr -d '\r' | tr -d ' ')
izinsc="https://github.com/hokagelegendshop-script/aksses/raw/refs/heads/main/permission"

checking_sc() {
    get_permission=$(curl -sSL "$izinsc")
    cek_ip=$(echo "$get_permission" | grep -w "$ipsaya")
    
    if [[ -z "$cek_ip" ]]; then
        clear
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        echo -e "\033[41m          404 NOT FOUND AUTOSCRIPT          \033[0m"
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        echo -e " IP VPS Anda : $ipsaya"
        echo -e " Status      : TIDAK TERDAFTAR!"
        echo -e " Silakan hubungi Admin untuk membeli skrip."
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        exit 1
    fi
    
    client_name=$(echo "$cek_ip" | awk '{print $2}')
    useexp=$(echo "$cek_ip" | awk '{print $3}')
    status_onoff=$(echo "$cek_ip" | awk '{print $5}')
    today=$(date +%Y-%m-%d)
    
    if [[ "$status_onoff" != "ON" ]]; then
        clear
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        echo -e "\033[41m             SCRIPT DISABLED                \033[0m"
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        echo -e " IP VPS Anda : $ipsaya"
        echo -e " Klien       : $client_name"
        echo -e " Status      : DIBLOKIR / SUSPEND"
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        exit 1
    fi
    
    if [[ "$today" > "$useexp" ]]; then
        clear
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        echo -e "\033[41m          SCRIPT EXPIRED / KADALUARSA       \033[0m"
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        echo -e " IP VPS Anda : $ipsaya"
        echo -e " Klien       : $client_name"
        echo -e " Expired     : $useexp"
        echo -e " Silakan hubungi Admin untuk perpanjangan."
        echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
        exit 1
    fi
}

checking_sc

# ==========================================
# MENU UTAMA WIREGUARD
# ==========================================
clear
print_yellow "════════════════════════════════════════════════════"
echo -e "${YELLOW}        WIREGUARD MANAGEMENT MENU               ${NC}"
print_yellow "   ══════════════════════════════════      "
echo -e "  \033[0;32m[1]\033[0m Buat Akun WireGuard (Create)"
echo -e "  \033[0;32m[2]\033[0m Cek Akun WireGuard  (Read)"
echo -e "  \033[0;32m[3]\033[0m Perpanjang Akun     (Update)"
echo -e "  \033[0;32m[4]\033[0m Hapus Akun          (Delete)"
echo -e "  \033[1;33m[5]\033[0m Cek User Online     (Monitor)"
echo -e "  \033[0;31m[0]\033[0m Kembali ke Menu Utama"
print_yellow "════════════════════════════════════════════════════"
read -p " Masukkan Pilihan Anda [0-5] : " wg_opt

case $wg_opt in
    1) bash /usr/bin/vpn-script/script/add-wg.sh ;;
    2) bash /usr/bin/vpn-script/script/cek-wg.sh ;;
    3) bash /usr/bin/vpn-script/script/renew-wg.sh ;;
    4) bash /usr/bin/vpn-script/script/del-wg.sh ;;
    5) bash /usr/bin/vpn-script/script/cek-wg-online.sh ;;
    0) vpn ;;
    *) echo "Pilihan tidak valid!"; sleep 2; bash /usr/bin/vpn-script/script/menu-wg.sh ;;
esac