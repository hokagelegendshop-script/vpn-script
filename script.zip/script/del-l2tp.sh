#!/bin/bash
clear
echo "======================================"
echo "         HAPUS AKUN L2TP/PPTP         "
echo "======================================"

# Ekstrak daftar pengguna aktif dari database (mengabaikan komentar dan baris kosong)
mapfile -t list_users < <(grep -vE "^#|^$" /etc/ppp/chap-secrets | awk '{print $1}' | sed 's/"//g')

if [ ${#list_users[@]} -eq 0 ]; then
    echo "❌ Belum ada pengguna L2TP/PPTP yang terdaftar."
    echo "======================================"
    exit 0
fi

# Tampilkan daftar pengguna beserta nomor urut dan expired date
for i in "${!list_users[@]}"; do
    nomor=$((i + 1))
    exp=$(grep -E "^\"?${list_users[$i]}\"? " /etc/ppp/chap-secrets | head -n 1 | awk -F'Exp: ' '{print $2}' | tr -d ' ')
    [[ -z "$exp" ]] && exp="Tidak Terbatas"
    echo "$nomor. ${list_users[$i]} (Exp: $exp)"
done
echo "======================================"
read -p "Masukkan Nomor Urut ATAU Username: " input_user

target_user=""

# Cek apakah input berupa angka (nomor urut) yang valid
if [[ "$input_user" =~ ^[0-9]+$ ]] && [ "$input_user" -ge 1 ] && [ "$input_user" -le ${#list_users[@]} ]; then
    idx=$((input_user - 1))
    target_user="${list_users[$idx]}"
else
    # Cek apakah input berupa teks (username) yang valid
    for u in "${list_users[@]}"; do
        if [ "$u" == "$input_user" ]; then
            target_user="$input_user"
            break
        fi
    done
fi

if [ -z "$target_user" ]; then
    echo "❌ Nomor atau Username tidak ditemukan di database!"
    exit 0
fi

# Proses Penghapusan (Mendukung format nama dengan atau tanpa tanda kutip)
sed -i "/^\"$target_user\" /d" /etc/ppp/chap-secrets
sed -i "/^$target_user /d" /etc/ppp/chap-secrets

echo "✅ Akun L2TP/PPTP '$target_user' berhasil dihapus dari sistem!"
