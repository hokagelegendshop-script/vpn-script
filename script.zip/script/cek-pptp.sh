#!/bin/bash
clear

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'
purple="\033[1;95m"

FILE_SECRETS="/etc/ppp/chap-secrets"
DIR_CONFIG="/usr/bin/vpn-script/dashboard-user/config-pptp"

echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
echo -e "${purple}               CEK DETAIL AKUN PPTP                 ${NC}"
echo -e "${CYAN}════════════════════════════════════════════════════${NC}"

# Mengambil daftar user PPTP ke dalam array
users=($(awk '$2 == "pptpd" {print $1}' "$FILE_SECRETS" | tr -d '"'))

if [ ${#users[@]} -eq 0 ]; then
    echo -e "${RED}Tidak ada akun PPTP yang terdaftar.${NC}"
    echo ""
    read -n 1 -s -r -p "Tekan [Enter] untuk kembali..."
    exit 1
fi

echo -e "Daftar Akun PPTP:"
for i in "${!users[@]}"; do
    echo -e " [${GREEN}$((i+1))${NC}] ${users[$i]}"
done
echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
read -p "Masukkan Nomor atau Username : " input

# Menentukan user berdasarkan input (jika angka maka ambil dari array, jika teks jadikan username)
if [[ "$input" =~ ^[0-9]+$ ]] && [ "$input" -ge 1 ] && [ "$input" -le "${#users[@]}" ]; then
    user="${users[$((input-1))]}"
else
    user="$input"
fi

# Cek keberadaan user di database PPTP
cek=$(awk -v u="$user" '($1 == u || $1 == "\""u"\"") && $2 == "pptpd"' "$FILE_SECRETS" | wc -l)

if [ "$cek" -eq 0 ]; then
    echo -e "\n${RED}Gagal: Akun PPTP '$user' tidak ditemukan!${NC}"
    echo ""
    read -n 1 -s -r -p "Tekan [Enter] untuk kembali..."
    exit 1
fi

# Mengambil Password dari chap-secrets
pass=$(awk -v u="$user" '($1 == u || $1 == "\""u"\"") && $2 == "pptpd" {print $3}' "$FILE_SECRETS" | tr -d '"')

# Mengambil data dari file config jika tersedia
if [ -f "${DIR_CONFIG}/${user}.conf" ]; then
    exp=$(grep "^Expired=" "${DIR_CONFIG}/${user}.conf" | cut -d= -f2)
    limit_ip=$(grep "^LimitIP=" "${DIR_CONFIG}/${user}.conf" | cut -d= -f2)
    limit_kuota=$(grep "^LimitKuota=" "${DIR_CONFIG}/${user}.conf" | cut -d= -f2)
else
    # Fallback jika file config terhapus atau belum ada
    exp=$(grep -w "^\"*$user\"*" "$FILE_SECRETS" | grep "pptpd" | awk -F"Exp: " '{print $2}')
    if [ -z "$exp" ]; then exp="Tidak Diketahui"; fi
    limit_ip="-"
    limit_kuota="-"
fi

# Menghitung sisa hari
if [[ "$exp" != "Tidak Diketahui" && "$exp" != "" ]]; then
    sisa_hari=$(( ($(date -d "$exp" +%s) - $(date +%s)) / 86400 ))
    if [[ $sisa_hari -lt 0 ]]; then
        sisa_hari_teks="${RED}Expired (${sisa_hari} Hari)${NC}"
    else
        sisa_hari_teks="${GREEN}${sisa_hari} Hari${NC}"
    fi
else
    sisa_hari_teks="-"
fi

ipsaya=$(curl -sSL ifconfig.me | tr -d '\n' | tr -d '\r' | tr -d ' ')

clear
echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}               DETAIL INFORMASI AKUN                ${NC}"
echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
echo -e "Username    : ${user}"
echo -e "Password    : ${pass}"
echo -e "IP Address  : ${ipsaya}"
echo -e "Expired     : ${exp}"
echo -e "Sisa Aktif  : ${sisa_hari_teks}"
echo -e "Limit IP    : ${limit_ip} Device"
echo -e "Limit Kuota : ${limit_kuota} Megabytes"
echo -e "${CYAN}════════════════════════════════════════════════════${NC}"
echo ""
read -n 1 -s -r -p "Ketik Enter untuk kembali..."