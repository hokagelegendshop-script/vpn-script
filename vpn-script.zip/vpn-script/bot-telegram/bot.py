import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import config
from core import vpn_handler

# Inisialisasi Bot
bot = telebot.TeleBot(config.BOT_TOKEN)

# Dictionary untuk menyimpan state memori (Mode Tampilan Admin)
user_view_mode = {}

def get_role(chat_id):
    if str(chat_id) == config.ADMIN_ID:
        return user_view_mode.get(chat_id, 'admin')
    return 'user'

# ==========================================================
# FUNGSI PEMBANTU UNTUK TRANSISI TEKS <-> FOTO YANG MULUS
# ==========================================================
def replace_with_text(bot, call, text, markup):
    try:
        if call.message.content_type == 'photo':
            bot.delete_message(call.message.chat.id, call.message.message_id)
            bot.send_message(call.message.chat.id, text, reply_markup=markup, parse_mode='Markdown')
        else:
            bot.edit_message_text(
                chat_id=call.message.chat.id,
                message_id=call.message.message_id,
                text=text,
                reply_markup=markup,
                parse_mode='Markdown'
            )
    except Exception as e:
        print(f"Error editing message: {e}")

def replace_with_photo(bot, call, photo_id, text, markup):
    try:
        if call.message.content_type == 'text':
            bot.delete_message(call.message.chat.id, call.message.message_id)
            bot.send_photo(call.message.chat.id, photo_id, caption=text, reply_markup=markup, parse_mode='Markdown')
        else:
            bot.edit_message_caption(
                chat_id=call.message.chat.id,
                message_id=call.message.message_id,
                caption=text,
                reply_markup=markup,
                parse_mode='Markdown'
            )
    except Exception as e:
        print(f"Error editing photo: {e}")

# ==========================================================
# FUNGSI TEKS DINAMIS UNTUK KATALOG VPN
# ==========================================================
def get_vpn_info_text(vpn_name):
    return (
        f"⚡ *PREMIUM {vpn_name} SERVER* ⚡\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"Nikmati koneksi tingkat tinggi dengan privasi maksimal. Cocok untuk *Browsing, Streaming, & Gaming* tanpa hambatan!\n\n"
        f"💳 *Tarif Layanan* : Rp 20.000 / Bulan\n"
        f"📱 *Limit Device*  : Max 3 IP Bersamaan\n"
        f"📊 *Limit Kuota*   : 200 GB (Kecepatan Penuh)\n\n"
        f"⚠️ _Syarat & Ketentuan:_\n"
        f"_Untuk melakukan pembuatan akun {vpn_name} baru, pastikan saldo di dompet Anda minimal tersedia *Rp 20.000*._\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"🛠 *Silakan pilih tindakan operasional di bawah ini:*"
    )

# ==========================================================
# FUNGSI PEMBUAT TAMPILAN MENU
# ==========================================================
def get_start_markup(chat_id):
    markup = InlineKeyboardMarkup()
    if str(chat_id) == config.ADMIN_ID:
        markup.row(
            InlineKeyboardButton("👑 Admin", callback_data="role_admin"),
            InlineKeyboardButton("💼 Reseller", callback_data="role_reseller"),
            InlineKeyboardButton("👤 User", callback_data="role_user")
        )
    markup.add(InlineKeyboardButton("📋 Tampilkan Menu", callback_data="show_menu"))
    return markup

def get_admin_menu():
    markup = InlineKeyboardMarkup()
    markup.row_width = 2
    markup.add(
        InlineKeyboardButton("🌐 WireGuard", callback_data="menu_wg"),
        InlineKeyboardButton("🔒 SSTP", callback_data="menu_sstp"),
        InlineKeyboardButton("🔑 PPTP", callback_data="menu_pptp"),
        InlineKeyboardButton("🛡️ L2TP", callback_data="menu_l2tp")
    )
    markup.row(InlineKeyboardButton("❌ Tutup Menu", callback_data="close_menu"))
    return markup

def get_reseller_menu():
    markup = InlineKeyboardMarkup()
    markup.row_width = 2
    markup.add(
        InlineKeyboardButton("➕ Buat Akun Klien", callback_data="res_create"),
        InlineKeyboardButton("⏳ Perpanjang Klien", callback_data="res_extend"),
        InlineKeyboardButton("💰 Cek Saldo", callback_data="res_balance")
    )
    markup.row(InlineKeyboardButton("❌ Tutup Menu", callback_data="close_menu"))
    return markup

def get_user_menu():
    markup = InlineKeyboardMarkup()
    markup.row_width = 1
    markup.add(
        InlineKeyboardButton("🔍 Cek Status Akunku", callback_data="usr_check"),
        InlineKeyboardButton("🛒 Beli VPN Baru", callback_data="usr_buy_vpn"),
        InlineKeyboardButton("🎧 Hubungi Bantuan", callback_data="usr_cs")
    )
    markup.row(InlineKeyboardButton("❌ Tutup Menu", callback_data="close_menu"))
    return markup

def get_user_buy_menu():
    markup = InlineKeyboardMarkup()
    markup.row_width = 2
    markup.add(
        InlineKeyboardButton("🌐 WireGuard", callback_data="buy_wg"),
        InlineKeyboardButton("🔒 SSTP", callback_data="buy_sstp"),
        InlineKeyboardButton("🔑 PPTP", callback_data="buy_pptp"),
        InlineKeyboardButton("🛡️ L2TP", callback_data="buy_l2tp")
    )
    markup.row(InlineKeyboardButton("🔙 Kembali ke Profil", callback_data="show_menu"))
    return markup

# --- GENERATOR SUB-MENU DINAMIS BERDASARKAN ROLE ---
def get_submenu_markup(proto, role):
    markup = InlineKeyboardMarkup()
    markup.row_width = 2
    markup.add(
        InlineKeyboardButton("➕ Buat Akun", callback_data=f"{proto}_create"),
        InlineKeyboardButton("⏳ Perpanjang", callback_data=f"{proto}_extend"),
        InlineKeyboardButton("🔍 Cek Akun", callback_data=f"{proto}_check"),
        InlineKeyboardButton("🗑️ Hapus Akun", callback_data=f"{proto}_delete")
    )
    
    # Logika Cerdas Tombol Kembali
    if role == 'user':
        # Jika User, kembalikan ke Katalog VPN
        markup.row(InlineKeyboardButton("🔙 Kembali ke Katalog", callback_data="usr_buy_vpn"))
    else:
        # Jika Admin/Reseller, kembalikan ke Menu Utama
        markup.row(InlineKeyboardButton("🔙 Kembali ke Menu Utama", callback_data="show_menu"))
        
    return markup

# ==========================================================
# HANDLER COMMAND UTAMA
# ==========================================================
@bot.message_handler(commands=['start'])
def send_welcome(message):
    chat_id = message.chat.id
    mode = get_role(chat_id).capitalize()
    
    if str(chat_id) == config.ADMIN_ID:
        welcome_text = (
            "🤖 *Selamat Datang di Hokage Legend VPN Bot* 🤖\n\n"
            f"Status Anda: *Administrator*\n"
            f"Mode Tampilan Saat Ini: *{mode}*\n\n"
            "Gunakan tombol di bawah untuk berpindah mode tampilan (Role Switch) "
            "sebelum masuk ke dalam menu dasbor."
        )
    else:
        welcome_text = (
            "🤖 *Selamat Datang di Hokage Legend VPN Bot* 🤖\n\n"
            "Saya adalah asisten otomatis untuk manajemen layanan VPN Anda.\n"
            "Silakan klik tombol di bawah ini untuk melihat daftar layanan kami."
        )
    
    bot.reply_to(message, welcome_text, parse_mode='Markdown', reply_markup=get_start_markup(chat_id))

# ==========================================================
# HANDLER CALLBACK (NAVIGASI TOMBOL INTERAKTIF)
# ==========================================================
@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    chat_id = call.message.chat.id
    
    # 0. Navigasi Role Switch
    if call.data.startswith("role_"):
        mode = call.data.split("_")[1]
        user_view_mode[chat_id] = mode
        bot.answer_callback_query(call.id, f"✅ Beralih ke UI {mode.capitalize()}")
        
        welcome_text = (
            "🤖 *Selamat Datang di Hokage Legend VPN Bot* 🤖\n\n"
            f"Status Anda: *Administrator*\n"
            f"Mode Tampilan Saat Ini: *{mode.capitalize()}*\n\n"
            "Gunakan tombol di bawah untuk berpindah mode tampilan (Role Switch) "
            "sebelum masuk ke dalam menu dasbor."
        )
        replace_with_text(bot, call, welcome_text, get_start_markup(chat_id))
        
    # 1. Navigasi ke Menu Utama
    elif call.data == "show_menu":
        mode = get_role(chat_id)
        if mode == 'admin':
            text = "🛠 *Menu Utama (Mode Admin)*\nAkses Penuh (Folder: dashboard-admin)\nSilakan pilih layanan VPN:"
            replace_with_text(bot, call, text, get_admin_menu())
            
        elif mode == 'reseller':
            text = "💼 *Menu Utama (Mode Reseller)*\nAkses Reseller (Folder: dashboard-reseller)\nKelola klien dan saldo Anda:"
            replace_with_text(bot, call, text, get_reseller_menu())
            
        else:
            first_name = call.from_user.first_name
            last_name = call.from_user.last_name if call.from_user.last_name else ""
            full_name = f"{first_name} {last_name}".strip()
            
            saldo = "Rp 0" 
            
            text = (
                f"👤 *PROFIL PENGGUNA*\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"Nama : *{full_name}*\n"
                f"ID Telegram : `{chat_id}`\n"
                f"Saldo : *{saldo}*\n"
                f"━━━━━━━━━━━━━━━━━━\n\n"
                f"🛠 *Menu Layanan Hokage Legend*\n"
                f"Silakan pilih operasional di bawah ini:"
            )
            
            markup = get_user_menu()
            photos = bot.get_user_profile_photos(chat_id)
            if photos.total_count > 0:
                best_photo_id = photos.photos[0][-1].file_id
                replace_with_photo(bot, call, best_photo_id, text, markup)
            else:
                replace_with_text(bot, call, text, markup)
        
    # 2. Navigasi Tutup Menu
    elif call.data == "close_menu":
        mode = get_role(chat_id).capitalize()
        if str(chat_id) == config.ADMIN_ID:
            text = f"🤖 *Menu ditutup.*\nMode Tampilan: *{mode}*\nSilakan klik tombol di bawah jika ingin membuka menu kembali."
        else:
            text = "🤖 *Menu ditutup.*\nSilakan klik tombol di bawah jika ingin membuka menu kembali."
            
        replace_with_text(bot, call, text, get_start_markup(chat_id))

    # 3. USER: BUKA KATALOG VPN 
    elif call.data == "usr_buy_vpn":
        bot.answer_callback_query(call.id, "Silakan lihat daftar VPN kami.")
        text = "🛒 *Pilih Protokol VPN*\nSilakan pilih layanan VPN yang ingin Anda beli:\n*(Harga akan ditarik dari saldo Anda)*"
        photos = bot.get_user_profile_photos(chat_id)
        
        if photos.total_count > 0:
            best_photo_id = photos.photos[0][-1].file_id
            replace_with_photo(bot, call, best_photo_id, text, get_user_buy_menu())
        else:
            replace_with_text(bot, call, text, get_user_buy_menu())

    # 4. BUKA MENU VPN (DINAMIS UNTUK SEMUA PROTOKOL)
    elif call.data in ["buy_wg", "menu_wg", "buy_sstp", "menu_sstp", "buy_pptp", "menu_pptp", "buy_l2tp", "menu_l2tp"]:
        proto = call.data.split("_")[1]
        nama_vpn = proto.upper()
        
        bot.answer_callback_query(call.id, f"Membuka Menu {nama_vpn}...")
        text = get_vpn_info_text(nama_vpn)
        
        mode = get_role(chat_id)
        if mode == 'user':
            photos = bot.get_user_profile_photos(chat_id)
            if photos.total_count > 0:
                best_photo_id = photos.photos[0][-1].file_id
                replace_with_photo(bot, call, best_photo_id, text, get_submenu_markup(proto, mode))
            else:
                replace_with_text(bot, call, text, get_submenu_markup(proto, mode))
        else:
            replace_with_text(bot, call, text, get_submenu_markup(proto, mode))

    # 5. CEK SALDO SAAT KLIK TOMBOL "BUAT AKUN" PADA SEMUA PROTOKOL
    elif call.data in ["wg_create", "sstp_create", "pptp_create", "l2tp_create"]:
        mode = get_role(chat_id)
        proto = call.data.split("_")[0].upper()
        
        if mode == 'user':
            current_saldo = 0 # Simulasi saldo
            harga_vpn = 20000 
            
            if current_saldo < harga_vpn:
                pesan_gagal = f"❌ Saldo Anda tidak cukup!\nSaldo saat ini: Rp {current_saldo}\nSyarat Minimal: Rp {harga_vpn}\nSilakan top-up terlebih dahulu."
                bot.answer_callback_query(call.id, text=pesan_gagal, show_alert=True)
            else:
                bot.answer_callback_query(call.id, "✅ Saldo mencukupi, memproses...")
                bot.send_message(chat_id, f"Masukkan username untuk VPN {proto} Anda:")
                
        else:
            bot.answer_callback_query(call.id, "Memproses pembuatan akun...")
            bot.send_message(chat_id, f"Mode {mode.capitalize()}: Masukkan username untuk VPN {proto} Anda:")

if __name__ == "__main__":
    print("🤖 Bot Hokage Legend sedang berjalan...")
    bot.infinity_polling(timeout=10, long_polling_timeout=5)