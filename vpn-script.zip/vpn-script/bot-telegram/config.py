# /usr/bin/vpn-script/bot-telegram/config.py

# Ganti dengan Token Bot Anda dari @BotFather
BOT_TOKEN = "8689860785:AAH_LOB6Sk_4FdQuJJCfVSYRQyHZXKve_Z4"

# Ganti dengan ID Telegram Anda (bisa didapat dari @userinfobot)
ADMIN_ID = "1469244768"

# Path ke file database SQLite
DB_PATH = "/usr/bin/vpn-script/bot-telegram/database/bot.sqlite"