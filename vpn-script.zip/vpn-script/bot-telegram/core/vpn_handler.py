# /usr/bin/vpn-script/bot-telegram/core/vpn_handler.py
import subprocess

def run_bash_script(command):
    """
    Fungsi untuk menjalankan perintah bash di terminal Ubuntu
    dan menangkap hasil outputnya.
    """
    try:
        # Menjalankan perintah bash
        result = subprocess.run(
            command,
            shell=True,
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        return True, result.stdout
    except subprocess.CalledProcessError as e:
        # Jika terjadi error pada script bash
        return False, e.stderr