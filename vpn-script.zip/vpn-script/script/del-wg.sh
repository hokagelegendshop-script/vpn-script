#!/bin/bash
clear
echo "=========================================="
echo "           HAPUS AKUN WIREGUARD           "
echo "=========================================="
read -p "Masukkan Username yang akan dihapus: " user

if grep -qw "^### Client $user" /etc/wireguard/wg0.conf; then
    # Dapatkan Public Key
    PUB_KEY=$(grep -A 1 "^### Client $user" /etc/wireguard/wg0.conf | grep "PublicKey" | awk '{print $3}')
    
    # Hapus dari service wg0 secara instan
    wg set wg0 peer "$PUB_KEY" remove
    
    # Hapus baris dari wg0.conf
    sed -i "/^### Client $user/,/^AllowedIPs/d" /etc/wireguard/wg0.conf
    
    # Hapus file konfigurasinya
    rm -f "/usr/bin/vpn-script/dashboard-user/config-wg/$user.conf"
    
    echo -e "\033[0;32mAkun $user berhasil dihapus!\033[0m"
else
    echo -e "\033[0;31mUsername $user tidak ditemukan!\033[0m"
fi
echo "=========================================="
echo "Ketik Enter untuk kembali..."
read
bash /usr/bin/vpn-script/script/menu-wg.sh