#!/bin/bash
# ==========================================
# MENU MANAGEMENT SSTP / L2TP / PPTP
# ==========================================
GREEN='\033[0;32m'
RED='\033[0;31m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m'

clear
echo -e "${CYAN}======================================================${NC}"
echo -e "${YELLOW}           MENU MANAGEMENT SSTP / L2TP / PPTP         ${NC}"
echo -e "${CYAN}======================================================${NC}"
echo -e "  ${GREEN}[1]${NC} Buat Akun Baru (Create)"
echo -e "  ${GREEN}[2]${NC} Cek Akun       (Read)   - ${RED}Segera Hadir${NC}"
echo -e "  ${GREEN}[3]${NC} Perpanjang     (Update) - ${RED}Segera Hadir${NC}"
echo -e "  ${GREEN}[4]${NC} Hapus Akun     (Delete) - ${RED}Segera Hadir${NC}"
echo -e "  ${RED}[0]${NC} Kembali ke Menu Utama"
echo -e "${CYAN}======================================================${NC}"
read -p " Masukkan Pilihan Anda [0-4] : " opt

case $opt in
    1)
        clear
        bash /usr/bin/vpn-script/script/add-sstp.sh
        ;;
    0)
        clear
        bash /usr/bin/vpn-script/script/menu.sh
        ;;
    *)
        echo -e "${RED}Pilihan tidak valid, silakan coba lagi.${NC}"
        sleep 2
        bash /usr/bin/vpn-script/script/menu-sstp.sh
        ;;
esac