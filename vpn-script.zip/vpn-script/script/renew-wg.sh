#!/bin/bash
clear
echo "=========================================="
echo "        PERPANJANG AKUN WIREGUARD         "
echo "=========================================="
read -p "Masukkan Username: " user

if grep -qw "^### Client $user" /etc/wireguard/wg0.conf; then
    read -p "Tambah masa aktif (Hari): " exp
    
    # Ambil tanggal expired lama
    old_exp=$(grep "^### Client $user" /etc/wireguard/wg0.conf | awk '{print $4}')
    
    # Cek expired date dengan logika
    today=$(date +%Y-%m-%d)
    if [[ "$today" > "$old_exp" ]]; then
        new_exp=$(date -d "+$exp days" +"%Y-%m-%d")
    else
        new_exp=$(date -d "$old_exp + $exp days" +"%Y-%m-%d")
    fi
    
    # Update tanggal di wg0.conf
    sed -i "s/^### Client $user $old_exp/### Client $user $new_exp/" /etc/wireguard/wg0.conf
    
    echo -e "\033[0;32mMasa aktif akun $user berhasil diperpanjang hingga $new_exp\033[0m"
else
    echo -e "\033[0;31mUsername $user tidak ditemukan!\033[0m"
fi
echo "=========================================="
echo "Ketik Enter untuk kembali..."
read
bash /usr/bin/vpn-script/script/menu-wg.sh