#!/bin/bash
clear
echo -e "\033[0;36m======================================================\033[0m"
echo -e "\033[1;33m              WIREGUARD MANAGEMENT MENU               \033[0m"
echo -e "\033[0;36m======================================================\033[0m"
echo -e "  \033[0;32m[1]\033[0m Buat Akun WireGuard (Create)"
echo -e "  \033[0;32m[2]\033[0m Cek Akun WireGuard  (Read)"
echo -e "  \033[0;32m[3]\033[0m Perpanjang Akun     (Update)"
echo -e "  \033[0;32m[4]\033[0m Hapus Akun          (Delete)"
echo -e "  \033[0;31m[0]\033[0m Kembali ke Menu Utama"
echo -e "\033[0;36m======================================================\033[0m"
read -p " Masukkan Pilihan Anda [0-4] : " wg_opt

case $wg_opt in
    1) bash /usr/bin/vpn-script/script/add-wg.sh ;;
    2) bash /usr/bin/vpn-script/script/cek-wg.sh ;;
    3) bash /usr/bin/vpn-script/script/renew-wg.sh ;;
    4) bash /usr/bin/vpn-script/script/del-wg.sh ;;
    0) bash /usr/bin/vpn-script/script/menu.sh ;;
    *) echo "Pilihan tidak valid!"; sleep 2; bash /usr/bin/vpn-script/script/menu-wg.sh ;;
esac