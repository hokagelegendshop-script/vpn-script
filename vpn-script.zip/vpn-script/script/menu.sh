#!/bin/bash

# ==========================================
# Definisi Warna untuk Indikator
# ==========================================
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# ==========================================
# Fungsi Cek Status Layanan
# ==========================================
# Memeriksa WireGuard (wg-quick@wg0)
if systemctl is-active --quiet wg-quick@wg0; then
    status_wg="${GREEN}🟢 ONLINE${NC}"
else
    status_wg="${RED}🔴 OFFLINE${NC}"
fi

# Memeriksa L2TP/IPsec (xl2tpd dan ipsec/strongswan)
if systemctl is-active --quiet xl2tpd && systemctl is-active --quiet ipsec; then
    status_l2tp="${GREEN}🟢 ONLINE${NC}"
else
    status_l2tp="${RED}🔴 OFFLINE${NC}"
fi

# Memeriksa SSTP (menggunakan accel-ppp sebagai standar)
if systemctl is-active --quiet accel-ppp; then
    status_sstp="${GREEN}🟢 ONLINE${NC}"
else
    status_sstp="${RED}🔴 OFFLINE${NC}"
fi

# Memeriksa PPTP (menggunakan pptpd sebagai standar)
if systemctl is-active --quiet pptpd; then
    status_pptp="${GREEN}🟢 ONLINE${NC}"
else
    status_pptp="${RED}🔴 OFFLINE${NC}"
fi

# ==========================================
# Tampilan Menu Utama
# ==========================================
clear
echo -e "${CYAN}======================================================${NC}"
echo -e "${YELLOW}              HOKAGE LEGEND VPN DASHBOARD             ${NC}"
echo -e "${CYAN}======================================================${NC}"
echo -e " Status Layanan Server:"
echo -e "  - WireGuard   : $status_wg"
echo -e "  - SSTP        : $status_sstp"
echo -e "  - PPTP        : $status_pptp"
echo -e "  - L2TP        : $status_l2tp"
echo -e "${CYAN}======================================================${NC}"
echo -e " Manajemen Akun (CRUD):"
echo -e "  ${GREEN}[1]${NC} Menu WireGuard "
echo -e "  ${GREEN}[2]${NC} Menu SSTP      "
echo -e "  ${GREEN}[3]${NC} Menu PPTP      "
echo -e "  ${GREEN}[4]${NC} Menu L2TP     "
echo -e "  ${RED}[0]${NC} Keluar"
echo -e "${CYAN}======================================================${NC}"
read -p " Masukkan Pilihan Anda [0-4] : " opt

# ==========================================
# Logika Eksekusi Menu
# ==========================================
case $opt in
    1)
        clear
        bash /usr/bin/vpn-script/script/menu-wg.sh
        ;;
    2)
        clear
        bash /usr/bin/vpn-script/script/menu-sstp.sh
        ;;
    3)
        clear
        bash /usr/bin/vpn-script/script/menu-pptp.sh
        ;;
    4)
        clear
        bash /usr/bin/vpn-script/script/menu-l2tp.sh
        ;;
    0)
        clear
        echo -e "${GREEN}Keluar dari VPN Dashboard...${NC}"
        exit 0
        ;;
    *)
        echo -e "${RED}Pilihan tidak valid, silakan coba lagi.${NC}"
        sleep 2
        bash /usr/bin/vpn-script/script/menu.sh
        ;;
esac