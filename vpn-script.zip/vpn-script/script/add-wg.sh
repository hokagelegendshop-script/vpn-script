#!/bin/bash
clear

# Ambil IP Public Server dan Public Key Server
SERVER_PUB_IP=$(wget -qO- ipv4.icanhazip.com)
SERVER_PUB_KEY=$(cat /etc/wireguard/server_public_key)

read -p "Masukkan Username: " user

# Validasi jika user sudah ada
if grep -qw "^### Client $user" /etc/wireguard/wg0.conf; then
    echo -e "\033[0;31mUsername $user sudah ada!\033[0m"
    sleep 2
    bash /usr/bin/vpn-script/script/menu-wg.sh
    exit 1
fi

read -p "Masa aktif (Hari): " exp

# Generate IP Client Secara Otomatis
LAST_IP=$(grep -oP 'AllowedIPs = 10\.66\.66\.\K[0-9]+' /etc/wireguard/wg0.conf | sort -n | tail -1)
if [ -z "$LAST_IP" ]; then
    CLIENT_IP="10.66.66.2"
else
    CLIENT_IP="10.66.66.$((LAST_IP+1))"
fi

# Generate Keys
CLIENT_PRIV_KEY=$(wg genkey)
CLIENT_PUB_KEY=$(echo "$CLIENT_PRIV_KEY" | wg pubkey)
CLIENT_PRE_SHARED_KEY=$(wg genpsk)

exp_date=$(date -d "+$exp days" +"%Y-%m-%d")

# Masukkan ke wg0.conf
cat <<EOF >> /etc/wireguard/wg0.conf
### Client $user $exp_date
[Peer]
PublicKey = $CLIENT_PUB_KEY
PresharedKey = $CLIENT_PRE_SHARED_KEY
AllowedIPs = $CLIENT_IP/32
EOF

# Terapkan config tanpa restart (agar koneksi user lain tidak putus)
wg set wg0 peer $CLIENT_PUB_KEY preshared-key <(echo $CLIENT_PRE_SHARED_KEY) allowed-ips $CLIENT_IP/32

# Buat file conf untuk user dan simpan di dashboard-user
mkdir -p /usr/bin/vpn-script/dashboard-user/config-wg
CLIENT_CONF="/usr/bin/vpn-script/dashboard-user/config-wg/$user.conf"

cat <<EOF > $CLIENT_CONF
[Interface]
PrivateKey = $CLIENT_PRIV_KEY
Address = $CLIENT_IP/24
DNS = 8.8.8.8, 8.8.4.4

[Peer]
PublicKey = $SERVER_PUB_KEY
PresharedKey = $CLIENT_PRE_SHARED_KEY
Endpoint = $SERVER_PUB_IP:51820
AllowedIPs = 0.0.0.0/0, ::/0
PersistentKeepalive = 25
EOF

# Tampilkan hasil di terminal
clear
echo "=========================================="
echo "       AKUN WIREGUARD BERHASIL DIBUAT     "
echo "=========================================="
echo " Username   : $user"
echo " IP Address : $CLIENT_IP"
echo " Expired    : $exp_date"
echo "=========================================="
echo " Konfigurasi tersimpan di :"
echo " $CLIENT_CONF"
echo "=========================================="
echo " "
echo -e "\033[1;33m⬇️ COPY TEXT DI BAWAH INI UNTUK APLIKASI WG ⬇️\033[0m"
echo "------------------------------------------"
cat $CLIENT_CONF
echo "------------------------------------------"
echo " "
echo "Ketik Enter untuk kembali..."
read
bash /usr/bin/vpn-script/script/menu-wg.sh