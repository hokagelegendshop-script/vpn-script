#!/bin/bash
# =========================================================
# MENU ADD USER SSTP / L2TP / PPTP (HOKAGE LEGEND)
# =========================================================

clear
echo "====================================================="
echo "          BUAT AKUN SSTP / L2TP / PPTP BARU          "
echo "====================================================="
read -p "Masukkan Username : " USER
read -p "Masukkan Password : " PASS

# Eksekusi pembuatan akun ke engine SoftEther
/usr/local/vpnserver/vpncmd localhost:5555 /SERVER /HUB:DEFAULT /CMD UserCreate $USER /GROUP:none /REALNAME:none /NOTE:none
/usr/local/vpnserver/vpncmd localhost:5555 /SERVER /HUB:DEFAULT /CMD UserPasswordSet $USER /PASSWORD:$PASS

PUB_IP=$(curl -s ifconfig.me || wget -qO- ipv4.icanhazip.com)

echo ""
echo "====================================================="
echo "                 AKUN BERHASIL DIBUAT                "
echo "====================================================="
echo "Protokol   : SSTP, L2TP/IPSec, PPTP"
echo "IP Server  : $PUB_IP"
echo "Username   : $USER"
echo "Password   : $PASS"
echo "IPSec PSK  : hokagelegend"
echo "====================================================="
