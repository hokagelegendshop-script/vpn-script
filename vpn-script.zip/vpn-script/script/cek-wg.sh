#!/bin/bash
clear
echo "=========================================="
echo "           DAFTAR AKUN WIREGUARD          "
echo "=========================================="
echo "Username       |  IP Address    | Expired"
echo "------------------------------------------"

grep -E "^### Client" /etc/wireguard/wg0.conf | cut -d ' ' -f 3,4 > /tmp/wg_users.txt
while read -r user exp; do
    ip=$(grep -A 3 "^### Client $user " /etc/wireguard/wg0.conf | grep "AllowedIPs" | awk '{print $3}' | cut -d '/' -f 1)
    printf "%-14s | %-14s | %s\n" "$user" "$ip" "$exp"
done < /tmp/wg_users.txt
rm -f /tmp/wg_users.txt

echo "=========================================="
echo "Ketik Enter untuk kembali..."
read
bash /usr/bin/vpn-script/script/menu-wg.sh